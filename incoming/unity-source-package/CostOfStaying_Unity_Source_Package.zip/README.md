# CostOfStaying Unity Source Package

This folder contains the reviewed Unity source payload supplied for **Cost of Staying (ثمن البقاء)**.

## Status

- Static review and source-level corrections: performed on 2026-11-01.
- Unity compilation: not run.
- NUnit EditMode/PlayMode tests: not run.
- FishNet 4.7.4R compatibility: not verified against an installed package.
- Gameplay implementation: incomplete; see `docs/audit/UNITY_SOURCE_PACKAGE_REVIEW.md`.
- Gameplay rules remain `PROPOSED FOR PLAYTEST`.

## Layout

- `Assets/CostOfStaying/Core` — engine-independent C# logic.
- `Assets/CostOfStaying/Net` — Unity/FishNet adapters.
- `Assets/CostOfStaying/Tests` — NUnit test assemblies.

This is not a complete Unity project. It does not include a package manifest, package lock, project version file, scenes, prefabs, or build settings. Import into a clean Unity 6.3 LTS project only after pinning the exact FishNet version.

See `docs/audit/UNITY_SOURCE_PACKAGE_REVIEW.md` for corrections, known gaps, and required verification gates.
