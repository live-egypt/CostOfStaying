# Unity Source Package Review

**Review date:** 2026-11-01  
**Source:** `CostOfStaying_Final.zip` supplied for this review  
**Status:** Imported source package — static review only; NOT BUILD-VERIFIED / NOT TEST-VERIFIED  
**Target assumptions:** Unity 6000.3 / Unity 6.3 LTS and FishNet 4.7.4R (neither is pinned or verified by a Unity project manifest/package lock in this source package).

## Package contents

- `Assets/CostOfStaying/Core`: pure C# domain and application logic.
- `Assets/CostOfStaying/Net`: FishNet and Unity integration adapters.
- `Assets/CostOfStaying/Tests/EditMode`: Core-focused NUnit tests.
- `Assets/CostOfStaying/Tests/Net`: networking adapter tests.
- `Superseded/`: excluded from the runtime source package; retained in the supplied archive as historical text only.

The package does not include a complete Unity project, `Packages/manifest.json`, `Packages/packages-lock.json`, `ProjectSettings/ProjectVersion.txt`, a FishNet package pin, or CI evidence for Unity compilation and Test Runner execution.

## Static corrections applied to this package

1. `CoreServerCommandIngress` now uses the actual `CommandEnvelope` constructor through `CommandEnvelopeFactory`, resolves the server-owned `ClientId` from the stored session, requires the Core session to be authenticated, and passes the authoritative server tick to the command queues. Client-provided requested ticks are not used as authority.
2. Movement and betrayal ingress calls now pass the required `currentTick` argument.
3. `SessionLifecycleServiceTests` now construct the service with its actual five-argument constructor and assert player/match cleanup after disconnect.
4. `ClientProjectionStateTests` imports the Core namespace for the `Result` type.
5. `CommandSequenceTracker` now enforces `MaximumSequenceJump`, with a regression test for excessive future sequence jumps.
6. `CorePipeline` exposes session sequence cleanup; the server session bridge invokes it on disconnect.
7. `CoreServerSessionBridge` authenticates the Core session after successful identity resolution and binding, with rollback on failure.
8. `FishNetServerAdapter` subscribes to FishNet `TimeManager.OnTick`, executes the single composed `CorePipeline`, and publishes per-session snapshots to authenticated connections.
9. FishNet broadcast registration disables the FishNet built-in authentication gate because this adapter uses its own Core session authentication gate. Both handlers reject commands unless the connection maps to an authenticated Core session. This must be reviewed together with the actual project's authentication integration.

## Confirmed gaps — do not treat this package as a completed game implementation

- `BetrayalService` currently applies direct Vitality damage. The proposed v2.1 gameplay baseline describes a complete Debuff Move/Transfer with capacity, range, cooldown, and atomicity. This is a gameplay-contract mismatch and remains a blocking design/implementation gap.
- `MovementService` applies deterministic planar movement but does not validate collision/world geometry, authoritative navigation constraints, or a server-side movement envelope beyond input normalization.
- `CorePipeline` currently processes Movement and Betrayal queues only. Vitality decay, Collapse transitions/debuffs, Endgame voting, Spirit behavior, and match outcome resolution are not implemented in this package.
- The server adapter requires the host application's trusted identity/authentication flow to call `AuthenticateConnection`. This package does not provide a complete account/session authentication protocol.
- Command outcomes are not yet emitted to clients by the server adapter; snapshots are emitted after each network tick.
- Disconnect currently removes the player from the authoritative match state. Whether that is the intended disconnect/reconnect gameplay policy remains unresolved.
- The `Superseded/` files were not copied into runtime paths. They are not treated as alternative execution paths.

## Verification status

| Check | Result |
|---|---|
| File inventory | PASS — 81 C# files under `Assets/CostOfStaying` |
| Core references to `UnityEngine` / `FishNet` | PASS — none found by static text scan |
| Duplicate declared types | PASS — no duplicate types found; generic and non-generic `Result` are valid overloads |
| Delimiter sanity | PASS — source was inspected; automated rough delimiter scan is not a compiler |
| Known source-level constructor/argument mismatches | Corrected in package; compiler not available here |
| Unity compilation | NOT RUN |
| NUnit EditMode tests | NOT RUN |
| FishNet 4.7.4R API compatibility | NOT VERIFIED against an installed 4.7.4R package |
| Dedicated server / host integration | NOT RUN |
| Gameplay conformance | NOT VERIFIED; gaps listed above |

## Required next verification gate

1. Import this package into a clean Unity 6000.3 project.
2. Pin the exact FishNet package version and preserve the package lock.
3. Compile all runtime and test assemblies.
4. Run EditMode and PlayMode tests and retain XML/TRX-equivalent evidence and Unity Editor logs.
5. Resolve the Betrayal Transfer contract and disconnect policy through an ADR before implementing those behaviors.
6. Add server integration tests for authentication, tick execution, snapshot revision monotonicity, and command outcome delivery.

No source in this package is labelled `VERIFIED` until those gates have reproducible evidence.
