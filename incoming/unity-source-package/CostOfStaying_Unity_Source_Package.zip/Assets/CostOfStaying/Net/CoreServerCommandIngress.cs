using CostOfStaying.Core;

namespace CostOfStaying.Net
{
    public sealed class CoreServerCommandIngress :
        IServerCommandIngress
    {
        private readonly CoreComposition _core;

        public CoreServerCommandIngress(
            CoreComposition core)
        {
            _core = core;
        }

        public Result EnqueueMovement(
            SessionId sessionId,
            MovementInput input,
            long clientSequence,
            long requestedTick)
        {
            if (sessionId.IsEmpty)
                return Result.Failure("command.session_empty");

            if (clientSequence < 0)
                return Result.Failure("command.sequence_invalid");

            if (!_core.Sessions.TryGet(sessionId, out PlayerSession session))
                return Result.Failure("command.session_missing");

            if (!session.IsAuthenticated)
                return Result.Failure("command.not_authenticated");

            // Client-supplied tick values are untrusted. Admission uses the
            // authoritative server tick, never the requestedTick payload.
            ServerTick serverTick = _core.Ticks.Current;
            Result<CommandEnvelope> envelope = _core.Envelopes.Create(
                sessionId, session.ClientId, clientSequence, serverTick);

            if (!envelope.IsSuccess)
                return Result.Failure(envelope.ErrorCode);

            var command = new MovementCommand(envelope.Value, input);
            return _core.MovementIngress.Enqueue(command, serverTick);
        }

        public Result EnqueueBetrayal(
            SessionId sessionId,
            PlayerId victimId,
            long clientSequence,
            long requestedTick)
        {
            if (sessionId.IsEmpty)
                return Result.Failure("command.session_empty");

            if (victimId.IsEmpty)
                return Result.Failure("command.victim_empty");

            if (clientSequence < 0)
                return Result.Failure("command.sequence_invalid");

            if (!_core.Sessions.TryGet(sessionId, out PlayerSession session))
                return Result.Failure("command.session_missing");

            if (!session.IsAuthenticated)
                return Result.Failure("command.not_authenticated");

            ServerTick serverTick = _core.Ticks.Current;
            Result<CommandEnvelope> envelope = _core.Envelopes.Create(
                sessionId, session.ClientId, clientSequence, serverTick);

            if (!envelope.IsSuccess)
                return Result.Failure(envelope.ErrorCode);

            var command = new BetrayalCommand(envelope.Value, victimId);
            return _core.BetrayalIngress.Enqueue(command, serverTick);
        }
    }
}
