using CostOfStaying.Core;

namespace CostOfStaying.Net
{
    public interface IServerSessionBridge
    {
        Result Connect(
            int clientId,
            PlayerId playerId,
            ServerTick tick);

        Result Disconnect(
            int clientId);
    }
}
