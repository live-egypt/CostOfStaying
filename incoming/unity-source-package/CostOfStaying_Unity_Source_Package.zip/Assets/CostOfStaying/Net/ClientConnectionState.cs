namespace CostOfStaying.Net
{
    public enum ClientConnectionState : byte
    {
        Offline = 0,
        Connecting = 1,
        Connected = 2,
        Disconnecting = 3
    }
}
