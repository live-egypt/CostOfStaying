using System;
using System.Collections.Generic;
using CostOfStaying.Core;

namespace CostOfStaying.Net
{
    public sealed class ClientProjectionState
    {
        private readonly Dictionary<
            PlayerId,
            ClientPlayerProjection>
            _players;

        private string _sessionId;

        public ServerTick ServerTick {
            get;
            private set;
        }

        public StateRevision Revision {
            get;
            private set;
        }

        public MatchSnapshotData Match {
            get;
            private set;
        }

        public IReadOnlyDictionary<
            PlayerId,
            ClientPlayerProjection>
            Players =>
            _players;

        public string SessionId =>
            _sessionId;

        public ClientProjectionState()
        {
            _players =
                new Dictionary<
                    PlayerId,
                    ClientPlayerProjection>();

            Reset();
        }

        public Result Apply(
            CoreSnapshotBroadcast snapshot)
        {
            if (string.IsNullOrWhiteSpace(
                    snapshot.SessionId))
            {
                return Result.Failure(
                    "client.snapshot_session_empty");
            }

            if (_sessionId != null &&
                _sessionId != snapshot.SessionId)
            {
                return Result.Failure(
                    "client.snapshot_wrong_session");
            }

            if (snapshot.ServerTick <
                ServerTick.Value)
            {
                return Result.Failure(
                    "client.snapshot_old_tick");
            }

            if (snapshot.StateRevision <
                Revision.Value)
            {
                return Result.Failure(
                    "client.snapshot_old_revision");
            }

            var nextPlayers =
                new Dictionary<
                    PlayerId,
                    ClientPlayerProjection>();

            if (snapshot.Players != null)
            {
                for (int i = 0;
                     i < snapshot.Players.Length;
                     i++)
                {
                    PlayerSnapshotData data =
                        snapshot.Players[i];

                    if (!Guid.TryParse(
                            data.PlayerId,
                            out Guid rawId))
                    {
                        continue;
                    }

                    Result<PlayerId> player =
                        PlayerId.TryCreate(
                            rawId);

                    if (!player.IsSuccess)
                    {
                        continue;
                    }

                    nextPlayers[player.Value] =
                        new ClientPlayerProjection(
                            player.Value,
                            data.Vitality,
                            data.IsAlive,
                            new Position2(
                                data.PositionX,
                                data.PositionY));
                }
            }

            _players.Clear();

            foreach (
                KeyValuePair<
                    PlayerId,
                    ClientPlayerProjection>
                    pair in nextPlayers)
            {
                _players.Add(
                    pair.Key,
                    pair.Value);
            }

            _sessionId =
                snapshot.SessionId;

            ServerTick =
                new ServerTick(
                    snapshot.ServerTick);

            Revision =
                new StateRevision(
                    snapshot.StateRevision);

            Match =
                snapshot.Match;

            return Result.Success();
        }

        public void Reset()
        {
            _sessionId =
                null;

            ServerTick =
                ServerTick.Zero;

            Revision =
                new StateRevision(0);

            Match =
                default;

            _players.Clear();
        }
    }

    public readonly struct ClientPlayerProjection
    {
        public PlayerId PlayerId {
            get;
        }

        public int Vitality {
            get;
        }

        public bool IsAlive {
            get;
        }

        public Position2 Position {
            get;
        }

        public ClientPlayerProjection(
            PlayerId playerId,
            int vitality,
            bool isAlive,
            Position2 position)
        {
            PlayerId =
                playerId;

            Vitality =
                vitality;

            IsAlive =
                isAlive;

            Position =
                position;
        }
    }
}
