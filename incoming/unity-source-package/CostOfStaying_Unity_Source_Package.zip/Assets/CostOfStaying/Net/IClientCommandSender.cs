using System;
using CostOfStaying.Core;

namespace CostOfStaying.Net
{
    public interface IClientCommandSender
    {
        Result StartClient();

        Result StopClient();

        Result SendMovement(
            MovementInput input,
            long requestedTick);

        Result SendBetrayal(
            Guid victimId,
            long requestedTick);
    }
}
