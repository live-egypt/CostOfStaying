using CostOfStaying.Core;

namespace CostOfStaying.Net
{
    public interface IClientCoreEvents
    {
        void OnConnecting();

        void OnConnected();

        void OnDisconnected();

        void OnSnapshotApplied(
            CoreSnapshotBroadcast snapshot,
            Result result);

        void OnCommandOutcome(
            CommandOutcomeBroadcast outcome);

        void OnRejected(
            string code,
            long serverTick);
    }

    public sealed class NullClientCoreEvents :
        IClientCoreEvents
    {
        public void OnConnecting()
        {
        }

        public void OnConnected()
        {
        }

        public void OnDisconnected()
        {
        }

        public void OnSnapshotApplied(
            CoreSnapshotBroadcast snapshot,
            Result result)
        {
        }

        public void OnCommandOutcome(
            CommandOutcomeBroadcast outcome)
        {
        }

        public void OnRejected(
            string code,
            long serverTick)
        {
        }
    }
}
