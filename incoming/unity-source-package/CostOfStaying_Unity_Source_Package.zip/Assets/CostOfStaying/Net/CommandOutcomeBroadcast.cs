using FishNet.Broadcast;

namespace CostOfStaying.Net
{
    public struct CommandOutcomeBroadcast :
        IBroadcast
    {
        public byte Kind;
        public long ClientSequence;
        public bool Accepted;
        public string Code;
        public long ServerTick;
    }
}
