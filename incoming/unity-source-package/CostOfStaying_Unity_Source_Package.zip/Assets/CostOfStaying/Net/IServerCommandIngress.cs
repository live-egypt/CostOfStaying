using CostOfStaying.Core;

namespace CostOfStaying.Net
{
    public interface IServerCommandIngress
    {
        Result EnqueueMovement(
            SessionId sessionId,
            MovementInput input,
            long clientSequence,
            long requestedTick);

        Result EnqueueBetrayal(
            SessionId sessionId,
            PlayerId victimId,
            long clientSequence,
            long requestedTick);
    }
}
