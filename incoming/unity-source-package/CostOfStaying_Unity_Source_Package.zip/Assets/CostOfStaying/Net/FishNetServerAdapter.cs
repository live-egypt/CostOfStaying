using System;
using System.Collections.Generic;
using CostOfStaying.Core;
using FishNet;
using FishNet.Connection;
using FishNet.Managing.Server;
using FishNet.Managing.Timing;
using FishNet.Transporting;
using UnityEngine;

namespace CostOfStaying.Net
{
    public sealed class FishNetServerAdapter :
        MonoBehaviour
    {
        [SerializeField]
        private bool _registerOnEnable = true;

        [SerializeField]
        private bool _logEvents = true;

        private CoreComposition _core;

        private IServerIdentityResolver
            _identity;

        private IServerConnectionRejector
            _rejector;

        private CoreServerCommandIngress
            _commands;

        private CoreServerSessionBridge
            _sessionBridge;

        private ConnectionSessionMap
            _sessionMap;

        private PendingConnectionRegistry
            _pending;

        private TimeManager _timeManager;
        private long _serverTickCounter;

        private bool _initialized;
        private bool _registered;

        public bool IsInitialized =>
            _initialized;

        public bool IsRegistered =>
            _registered;

        public ServerTick CurrentServerTick =>
            _core == null
                ? ServerTick.Zero
                : _core.Ticks.Current;

        public int SessionCount =>
            _sessionMap == null
                ? 0
                : _sessionMap.Count;

        public int PendingCount =>
            _pending == null
                ? 0
                : _pending.Count;

        public void Initialize(
            CoreComposition core,
            IServerIdentityResolver identity,
            IServerConnectionRejector rejector)
        {
            if (_initialized)
            {
                throw new InvalidOperationException(
                    "Server adapter already initialized.");
            }

            if (core == null)
            {
                throw new ArgumentNullException(
                    nameof(core));
            }

            if (identity == null)
            {
                throw new ArgumentNullException(
                    nameof(identity));
            }

            if (rejector == null)
            {
                throw new ArgumentNullException(
                    nameof(rejector));
            }

            _core =
                core;

            _identity =
                identity;

            _rejector =
                rejector;

            _sessionMap =
                new ConnectionSessionMap();

            _pending =
                new PendingConnectionRegistry();

            _sessionBridge =
                new CoreServerSessionBridge(
                    _core,
                    _sessionMap);

            _commands =
                new CoreServerCommandIngress(
                    _core);

            _initialized =
                true;

            if (_registerOnEnable &&
                isActiveAndEnabled)
            {
                Register();
            }
        }

        public void Register()
        {
            if (!_initialized ||
                _registered)
            {
                return;
            }

            ServerManager server =
                InstanceFinder.ServerManager;

            if (server == null)
            {
                LogWarning(
                    "ServerManager is missing.");

                return;
            }

            // Custom session authentication is enforced by the Core session map
            // in each handler; FishNet's built-in auth gate is intentionally off.
            server.RegisterBroadcast<
                MovementInputBroadcast>(
                    OnMovement,
                    false);

            server.RegisterBroadcast<
                BetrayalRequestBroadcast>(
                    OnBetrayal,
                    false);

            server.OnRemoteConnectionState +=
                OnRemoteConnectionState;

            _timeManager =
                InstanceFinder.TimeManager;

            if (_timeManager != null)
            {
                _timeManager.OnTick +=
                    OnServerTick;
            }
            else
            {
                LogWarning(
                    "TimeManager is missing; Core pipeline will not advance.");
            }

            _registered =
                true;

            Log(
                "ServerAdapter registered.");
        }

        public void Unregister()
        {
            if (!_registered)
            {
                return;
            }

            ServerManager server =
                InstanceFinder.ServerManager;

            if (server != null)
            {
                server.UnregisterBroadcast<
                    MovementInputBroadcast>(
                        OnMovement);

                server.UnregisterBroadcast<
                    BetrayalRequestBroadcast>(
                        OnBetrayal);

                server.OnRemoteConnectionState -=
                    OnRemoteConnectionState;
            }

            if (_timeManager != null)
            {
                _timeManager.OnTick -=
                    OnServerTick;
                _timeManager = null;
            }

            _registered =
                false;

            Log(
                "ServerAdapter unregistered.");
        }

        public Result AuthenticateConnection(
            NetworkConnection connection)
        {
            if (!_initialized)
            {
                return Result.Failure(
                    "server.not_initialized");
            }

            if (connection == null)
            {
                return Result.Failure(
                    "connection.null");
            }

            int clientId =
                connection.ClientId;

            if (!_pending.Contains(
                    clientId))
            {
                return Result.Failure(
                    "connection.not_pending");
            }

            if (_sessionMap.TryGet(
                    clientId,
                    out _))
            {
                return Result.Failure(
                    "connection.already_authenticated");
            }

            Result<PlayerId> identity =
                _identity.Resolve(
                    connection);

            if (!identity.IsSuccess)
            {
                Reject(
                    connection,
                    identity.ErrorCode);

                return Result.Failure(
                    identity.ErrorCode);
            }

            Result<SessionId> connected =
                _sessionBridge.Connect(
                    clientId,
                    identity.Value,
                    CurrentServerTick);

            if (!connected.IsSuccess)
            {
                Reject(
                    connection,
                    connected.ErrorCode);

                return Result.Failure(
                    connected.ErrorCode);
            }

            _pending.Remove(
                clientId);

            Log(
                "Connection authenticated: " +
                clientId);

            return Result.Success();
        }

        public Result DisconnectConnection(
            NetworkConnection connection)
        {
            if (!_initialized)
            {
                return Result.Failure(
                    "server.not_initialized");
            }

            if (connection == null)
            {
                return Result.Failure(
                    "connection.null");
            }

            int clientId =
                connection.ClientId;

            _pending.Remove(
                clientId);

            Result result =
                _sessionBridge.Disconnect(
                    clientId);

            if (!result.IsSuccess &&
                result.ErrorCode ==
                "connection.session_missing")
            {
                return Result.Success();
            }

            return result;
        }

        private void OnServerTick()
        {
            ServerManager server =
                InstanceFinder.ServerManager;

            if (!_initialized ||
                !_registered ||
                server == null ||
                !server.Started ||
                _core == null)
            {
                return;
            }

            if (_serverTickCounter < _core.Ticks.Current.Value)
                _serverTickCounter = _core.Ticks.Current.Value;

            if (_serverTickCounter == long.MaxValue)
            {
                LogWarning("Server tick counter exhausted; simulation stopped.");
                Unregister();
                return;
            }

            _serverTickCounter++;
            ServerTick tick = new ServerTick(_serverTickCounter);
            Result<CorePipelineResult> execution =
                _core.Pipeline.Execute(tick);

            if (!execution.IsSuccess)
            {
                LogWarning("Core pipeline rejected tick: " + execution.ErrorCode);
                return;
            }

            CoreSnapshot snapshot =
                _core.Snapshots.Create(tick);

            foreach (KeyValuePair<int, SessionId> entry in _sessionMap.Entries)
            {
                if (!server.Clients.TryGetValue(
                        entry.Key,
                        out NetworkConnection connection) ||
                    connection == null ||
                    !connection.IsAuthenticated)
                {
                    continue;
                }

                CoreSnapshotBroadcast broadcast =
                    CoreSnapshotMapper.ToBroadcast(
                        snapshot,
                        entry.Value);

                server.Broadcast(
                    connection,
                    broadcast,
                    true,
                    Channel.Unreliable);
            }
        }

        private void OnRemoteConnectionState(
            NetworkConnection connection,
            RemoteConnectionStateArgs args)
        {
            if (!_initialized ||
                connection == null)
            {
                return;
            }

            if (args.ConnectionState ==
                RemoteConnectionState.Started)
            {
                _pending.Add(
                    connection.ClientId);

                Log(
                    "Connection pending: " +
                    connection.ClientId);

                return;
            }

            if (args.ConnectionState ==
                RemoteConnectionState.Stopped)
            {
                DisconnectConnection(
                    connection);

                Log(
                    "Connection stopped: " +
                    connection.ClientId);
            }
        }

        private void OnMovement(
            NetworkConnection connection,
            MovementInputBroadcast message,
            Channel channel)
        {
            if (!TryGetAuthenticatedSession(
                    connection,
                    out SessionId sessionId))
            {
                Reject(
                    connection,
                    "command.session_missing");

                return;
            }

            var input =
                new MovementInput(
                    message.Horizontal,
                    message.Vertical,
                    message.Sprint);

            Result queued =
                _commands.EnqueueMovement(
                    sessionId,
                    input,
                    message.ClientSequence,
                    message.RequestedTick);

            if (!queued.IsSuccess)
            {
                Reject(
                    connection,
                    queued.ErrorCode);
            }
        }

        private void OnBetrayal(
            NetworkConnection connection,
            BetrayalRequestBroadcast message,
            Channel channel)
        {
            if (!TryGetAuthenticatedSession(
                    connection,
                    out SessionId sessionId))
            {
                Reject(
                    connection,
                    "command.session_missing");

                return;
            }

            Result<PlayerId> victim =
                PlayerId.TryCreate(
                    message.VictimId);

            if (!victim.IsSuccess)
            {
                Reject(
                    connection,
                    "command.victim_invalid");

                return;
            }

            Result queued =
                _commands.EnqueueBetrayal(
                    sessionId,
                    victim.Value,
                    message.ClientSequence,
                    message.RequestedTick);

            if (!queued.IsSuccess)
            {
                Reject(
                    connection,
                    queued.ErrorCode);
            }
        }

        private bool TryGetAuthenticatedSession(
            NetworkConnection connection,
            out SessionId sessionId)
        {
            sessionId =
                default;

            if (connection == null)
            {
                return false;
            }

            return _sessionMap.TryGet(
                connection.ClientId,
                out sessionId);
        }

        private void Reject(
            NetworkConnection connection,
            string code)
        {
            _rejector.Reject(
                connection,
                code,
                CurrentServerTick);
        }

        private void OnEnable()
        {
            if (_registerOnEnable)
            {
                Register();
            }
        }

        private void OnDisable()
        {
            Unregister();
        }

        private void OnDestroy()
        {
            Unregister();

            _sessionMap?.Clear();
            _pending?.Clear();
        }

        private void Log(
            string message)
        {
            if (_logEvents)
            {
                Debug.Log(
                    "[CostOfStaying.Server] " +
                    message,
                    this);
            }
        }

        private void LogWarning(
            string message)
        {
            if (_logEvents)
            {
                Debug.LogWarning(
                    "[CostOfStaying.Server] " +
                    message,
                    this);
            }
        }
    }
}
