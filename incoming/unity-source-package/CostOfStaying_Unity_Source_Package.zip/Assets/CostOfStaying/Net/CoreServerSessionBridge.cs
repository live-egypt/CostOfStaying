using CostOfStaying.Core;

namespace CostOfStaying.Net
{
    public sealed class CoreServerSessionBridge
    {
        private readonly CoreComposition
            _core;

        private readonly ConnectionSessionMap
            _sessions;

        public CoreServerSessionBridge(
            CoreComposition core,
            ConnectionSessionMap sessions)
        {
            _core =
                core;

            _sessions =
                sessions;
        }

        public Result<SessionId> Connect(
            int clientId,
            PlayerId playerId,
            ServerTick tick)
        {
            Result<PlayerSession> connected =
                _core.SessionLifecycle.Connect(
                    playerId,
                    clientId,
                    tick);

            if (!connected.IsSuccess)
            {
                return Result<SessionId>.Failure(
                    connected.ErrorCode);
            }

            Result bound =
                _sessions.Bind(
                    clientId,
                    connected.Value.SessionId);

            if (!bound.IsSuccess)
            {
                _core.SessionLifecycle.Disconnect(
                    connected.Value.SessionId);

                return Result<SessionId>.Failure(
                    bound.ErrorCode);
            }

            Result authenticated =
                _core.SessionLifecycle.Authenticate(
                    connected.Value.SessionId);

            if (!authenticated.IsSuccess)
            {
                _sessions.Remove(clientId);
                _core.SessionLifecycle.Disconnect(
                    connected.Value.SessionId);
                return Result<SessionId>.Failure(
                    authenticated.ErrorCode);
            }

            return Result<SessionId>.Success(
                connected.Value.SessionId);
        }

        public Result Disconnect(
            int clientId)
        {
            if (!_sessions.TryGet(
                    clientId,
                    out SessionId sessionId))
            {
                return Result.Failure(
                    "connection.session_missing");
            }

            Result disconnected =
                _core.SessionLifecycle.Disconnect(
                    sessionId);

            Result removed =
                _sessions.Remove(
                    clientId);

            if (disconnected.IsSuccess)
            {
                _core.Pipeline.RemoveSession(sessionId);
            }

            if (!disconnected.IsSuccess)
            {
                return disconnected;
            }

            return removed;
        }
    }
}
