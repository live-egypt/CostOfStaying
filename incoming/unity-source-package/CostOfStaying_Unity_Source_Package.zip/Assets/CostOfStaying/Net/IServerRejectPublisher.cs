using FishNet.Connection;

namespace CostOfStaying.Net
{
    public interface IServerRejectPublisher
    {
        void Reject(
            NetworkConnection connection,
            string code,
            long serverTick);
    }
}
