using System;
using CostOfStaying.Core;
using FishNet;
using FishNet.Managing.Client;
using FishNet.Transporting;
using UnityEngine;

namespace CostOfStaying.Net
{
    public sealed class FishNetClientAdapter :
        MonoBehaviour,
        IClientCommandSender
    {
        [Header("Lifecycle")]
        [SerializeField]
        private bool _registerOnEnable = true;

        [SerializeField]
        private bool _startOnStart = false;

        [SerializeField]
        private bool _stopOnDisable = false;

        [Header("Diagnostics")]
        [SerializeField]
        private bool _logEvents = true;

        private IClientCoreEvents _events;
        private ClientAdapterState _state;
        private ClientProjectionState _projection;

        private bool _initialized;
        private bool _registered;

        public bool IsInitialized =>
            _initialized;

        public bool IsRegistered =>
            _registered;

        public ClientConnectionState
            ConnectionState =>
            _state == null
                ? ClientConnectionState.Offline
                : _state.Connection;

        public ClientProjectionState Projection =>
            _projection;

        public long LastServerTick =>
            _state == null
                ? 0
                : _state.LastServerTick;

        public long LastSnapshotRevision =>
            _state == null
                ? 0
                : _state.LastSnapshotRevision;

        public void Initialize(
            IClientCoreEvents events)
        {
            if (_initialized)
            {
                throw new InvalidOperationException(
                    "ClientAdapter already initialized.");
            }

            _events =
                events ??
                new NullClientCoreEvents();

            _state =
                new ClientAdapterState();

            _projection =
                new ClientProjectionState();

            _initialized =
                true;

            if (_registerOnEnable &&
                isActiveAndEnabled)
            {
                Register();
            }
        }

        public void Register()
        {
            if (!_initialized ||
                _registered)
            {
                return;
            }

            ClientManager client =
                InstanceFinder.ClientManager;

            if (client == null)
            {
                LogWarning(
                    "ClientManager is missing.");

                return;
            }

            client.RegisterBroadcast<
                CoreSnapshotBroadcast>(
                    OnSnapshot);

            client.RegisterBroadcast<
                CoreRejectBroadcast>(
                    OnReject);

            client.RegisterBroadcast<
                CommandOutcomeBroadcast>(
                    OnCommandOutcome);

            client.OnClientConnectionState +=
                OnClientConnectionState;

            _registered =
                true;

            Log(
                "ClientAdapter registered.");
        }

        public void Unregister()
        {
            if (!_registered)
            {
                return;
            }

            ClientManager client =
                InstanceFinder.ClientManager;

            if (client != null)
            {
                client.UnregisterBroadcast<
                    CoreSnapshotBroadcast>(
                        OnSnapshot);

                client.UnregisterBroadcast<
                    CoreRejectBroadcast>(
                        OnReject);

                client.UnregisterBroadcast<
                    CommandOutcomeBroadcast>(
                        OnCommandOutcome);

                client.OnClientConnectionState -=
                    OnClientConnectionState;
            }

            _registered =
                false;

            Log(
                "ClientAdapter unregistered.");
        }

        public Result StartClient()
        {
            Result initialized =
                EnsureInitialized();

            if (!initialized.IsSuccess)
            {
                return initialized;
            }

            ClientManager client =
                InstanceFinder.ClientManager;

            if (client == null)
            {
                return Result.Failure(
                    "client.manager_missing");
            }

            if (client.Started)
            {
                return Result.Success();
            }

            _state.SetConnecting();
            _events.OnConnecting();

            client.StartConnection();

            return Result.Success();
        }

        public Result StopClient()
        {
            Result initialized =
                EnsureInitialized();

            if (!initialized.IsSuccess)
            {
                return initialized;
            }

            ClientManager client =
                InstanceFinder.ClientManager;

            if (client == null)
            {
                return Result.Failure(
                    "client.manager_missing");
            }

            if (!client.Started)
            {
                _state.SetOffline();
                _projection.Reset();

                return Result.Success();
            }

            _state.SetDisconnecting();

            client.StopConnection(
                true);

            return Result.Success();
        }

        public Result SendMovement(
            MovementInput input,
            long requestedTick)
        {
            Result ready =
                EnsureReadyToSend();

            if (!ready.IsSuccess)
            {
                return ready;
            }

            var message =
                new MovementInputBroadcast
                {
                    Horizontal =
                        input.Horizontal,

                    Vertical =
                        input.Vertical,

                    Sprint =
                        input.Sprint,

                    ClientSequence =
                        _state.NextMovementSequence(),

                    RequestedTick =
                        NormalizeTick(
                            requestedTick)
                };

            InstanceFinder.ClientManager
                .Broadcast(
                    message,
                    Channel.Unreliable);

            return Result.Success();
        }

        public Result SendBetrayal(
            Guid victimId,
            long requestedTick)
        {
            Result ready =
                EnsureReadyToSend();

            if (!ready.IsSuccess)
            {
                return ready;
            }

            if (victimId == Guid.Empty)
            {
                return Result.Failure(
                    "client.victim_empty");
            }

            var message =
                new BetrayalRequestBroadcast
                {
                    VictimId =
                        victimId,

                    ClientSequence =
                        _state.NextBetrayalSequence(),

                    RequestedTick =
                        NormalizeTick(
                            requestedTick)
                };

            InstanceFinder.ClientManager
                .Broadcast(
                    message,
                    Channel.Reliable);

            return Result.Success();
        }

        public void ResetLocalSession()
        {
            if (!_initialized)
            {
                return;
            }

            _state.ResetSession();
            _projection.Reset();
        }

        private void OnClientConnectionState(
            ClientConnectionStateArgs args)
        {
            if (args.ConnectionState ==
                LocalConnectionState.Started)
            {
                _state.SetConnected();
                _events.OnConnected();

                Log(
                    "Client connected.");

                return;
            }

            if (args.ConnectionState ==
                LocalConnectionState.Stopped)
            {
                _state.SetOffline();
                _projection.Reset();
                _events.OnDisconnected();

                Log(
                    "Client disconnected.");
            }
        }

        private void OnSnapshot(
            CoreSnapshotBroadcast message,
            Channel channel)
        {
            if (!_initialized)
            {
                return;
            }

            Result result =
                _projection.Apply(
                    message);

            if (result.IsSuccess)
            {
                _state.ApplySnapshot(
                    message.ServerTick,
                    message.StateRevision);
            }

            _events.OnSnapshotApplied(
                message,
                result);
        }

        private void OnReject(
            CoreRejectBroadcast message,
            Channel channel)
        {
            if (!_initialized)
            {
                return;
            }

            _events.OnRejected(
                message.Code,
                message.ServerTick);

            LogWarning(
                "Command rejected: " +
                message.Code);
        }

        private void OnCommandOutcome(
            CommandOutcomeBroadcast message,
            Channel channel)
        {
            if (!_initialized)
            {
                return;
            }

            _events.OnCommandOutcome(
                message);
        }

        private Result EnsureInitialized()
        {
            if (!_initialized ||
                _state == null ||
                _projection == null)
            {
                return Result.Failure(
                    "client.not_initialized");
            }

            return Result.Success();
        }

        private Result EnsureReadyToSend()
        {
            Result initialized =
                EnsureInitialized();

            if (!initialized.IsSuccess)
            {
                return initialized;
            }

            ClientManager client =
                InstanceFinder.ClientManager;

            if (client == null)
            {
                return Result.Failure(
                    "client.manager_missing");
            }

            if (!client.Started)
            {
                return Result.Failure(
                    "client.not_started");
            }

            if (_state.Connection !=
                ClientConnectionState.Connected)
            {
                return Result.Failure(
                    "client.not_connected");
            }

            return Result.Success();
        }

        private static long NormalizeTick(
            long requestedTick)
        {
            return requestedTick < 0
                ? 0
                : requestedTick;
        }

        private void OnEnable()
        {
            if (_registerOnEnable &&
                _initialized)
            {
                Register();
            }
        }

        private void Start()
        {
            if (_startOnStart)
            {
                StartClient();
            }
        }

        private void OnDisable()
        {
            if (_stopOnDisable &&
                _initialized)
            {
                StopClient();
            }

            Unregister();
        }

        private void OnDestroy()
        {
            Unregister();
        }

        private void Log(
            string message)
        {
            if (_logEvents)
            {
                Debug.Log(
                    "[CostOfStaying.Client] " +
                    message,
                    this);
            }
        }

        private void LogWarning(
            string message)
        {
            if (_logEvents)
            {
                Debug.LogWarning(
                    "[CostOfStaying.Client] " +
                    message,
                    this);
            }
        }
    }
}
