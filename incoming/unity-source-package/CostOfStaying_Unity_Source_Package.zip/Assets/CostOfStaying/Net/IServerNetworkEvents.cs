namespace CostOfStaying.Net
{
    public interface IServerNetworkEvents
    {
        void Register();

        void Unregister();
    }
}
