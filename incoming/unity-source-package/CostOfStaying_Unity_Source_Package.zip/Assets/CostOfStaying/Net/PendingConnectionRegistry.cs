using System.Collections.Generic;

namespace CostOfStaying.Net
{
    public sealed class PendingConnectionRegistry
    {
        private readonly HashSet<int>
            _clientIds;

        public PendingConnectionRegistry()
        {
            _clientIds =
                new HashSet<int>();
        }

        public bool Add(
            int clientId)
        {
            return _clientIds.Add(
                clientId);
        }

        public bool Remove(
            int clientId)
        {
            return _clientIds.Remove(
                clientId);
        }

        public bool Contains(
            int clientId)
        {
            return _clientIds.Contains(
                clientId);
        }

        public void Clear()
        {
            _clientIds.Clear();
        }
    }
}
