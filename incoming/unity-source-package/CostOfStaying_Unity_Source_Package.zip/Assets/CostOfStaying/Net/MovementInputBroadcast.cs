using FishNet.Broadcast;

namespace CostOfStaying.Net
{
    public struct MovementInputBroadcast :
        IBroadcast
    {
        public short Horizontal;
        public short Vertical;
        public bool Sprint;
        public long ClientSequence;
        public long RequestedTick;
    }
}
