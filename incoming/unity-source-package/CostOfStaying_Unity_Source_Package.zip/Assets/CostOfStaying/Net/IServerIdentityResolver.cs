using CostOfStaying.Core;

namespace CostOfStaying.Net
{
    public interface IServerIdentityResolver
    {
        Result<PlayerId> Resolve(
            int clientId);
    }
}
