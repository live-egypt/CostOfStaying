using System;
using FishNet.Broadcast;

namespace CostOfStaying.Net
{
    public struct BetrayalRequestBroadcast :
        IBroadcast
    {
        public Guid VictimId;
        public long ClientSequence;
        public long RequestedTick;
    }
}
