using FishNet.Broadcast;

namespace CostOfStaying.Net
{
    public struct CoreSnapshotBroadcast :
        IBroadcast
    {
        public string SessionId;
        public long ServerTick;
        public long StateRevision;
        public MatchSnapshotData Match;
        public PlayerSnapshotData[] Players;
    }

    public struct MatchSnapshotData
    {
        public byte Lifecycle;
        public int ConnectedPlayers;
        public int MaximumPlayers;
        public long Revision;
    }

    public struct PlayerSnapshotData
    {
        public string PlayerId;
        public int Vitality;
        public bool IsAlive;
        public float PositionX;
        public float PositionY;
    }
}
