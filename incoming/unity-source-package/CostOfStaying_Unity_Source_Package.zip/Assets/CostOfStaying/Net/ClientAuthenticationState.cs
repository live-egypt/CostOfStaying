namespace CostOfStaying.Net
{
    public enum ClientAuthenticationState : byte
    {
        None = 0,
        Requested = 1,
        Accepted = 2,
        Rejected = 3
    }
}
