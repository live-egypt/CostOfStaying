namespace CostOfStaying.Net
{
    public sealed class ClientAdapterState
    {
        private long _movementSequence;
        private long _betrayalSequence;

        public ClientConnectionState Connection {
            get;
            private set;
        }

        public long LastServerTick {
            get;
            private set;
        }

        public long LastSnapshotRevision {
            get;
            private set;
        }

        public ClientAdapterState()
        {
            ResetSession();
        }

        public void SetConnecting()
        {
            Connection =
                ClientConnectionState.Connecting;
        }

        public void SetConnected()
        {
            Connection =
                ClientConnectionState.Connected;
        }

        public void SetDisconnecting()
        {
            Connection =
                ClientConnectionState.Disconnecting;
        }

        public void SetOffline()
        {
            Connection =
                ClientConnectionState.Offline;
        }

        public long NextMovementSequence()
        {
            return ++_movementSequence;
        }

        public long NextBetrayalSequence()
        {
            return ++_betrayalSequence;
        }

        public void ApplySnapshot(
            long serverTick,
            long revision)
        {
            if (serverTick >= LastServerTick)
            {
                LastServerTick =
                    serverTick;
            }

            if (revision >= LastSnapshotRevision)
            {
                LastSnapshotRevision =
                    revision;
            }
        }

        public void ResetSession()
        {
            Connection =
                ClientConnectionState.Offline;

            LastServerTick =
                0;

            LastSnapshotRevision =
                0;

            _movementSequence =
                -1;

            _betrayalSequence =
                -1;
        }
    }
}
