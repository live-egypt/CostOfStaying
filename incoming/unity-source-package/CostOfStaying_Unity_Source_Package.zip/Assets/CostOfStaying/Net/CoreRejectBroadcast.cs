using FishNet.Broadcast;

namespace CostOfStaying.Net
{
    public struct CoreRejectBroadcast :
        IBroadcast
    {
        public string Code;
        public long ServerTick;
    }
}
