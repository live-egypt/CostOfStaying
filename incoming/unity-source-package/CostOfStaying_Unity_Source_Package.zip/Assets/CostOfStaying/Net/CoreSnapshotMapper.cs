using System;
using System.Collections.Generic;
using CostOfStaying.Core;

namespace CostOfStaying.Net
{
    public static class CoreSnapshotMapper
    {
        public static CoreSnapshotBroadcast ToBroadcast(
            CoreSnapshot snapshot,
            SessionId sessionId)
        {
            if (snapshot == null)
            {
                throw new ArgumentNullException(
                    nameof(snapshot));
            }

            IReadOnlyList<PlayerSnapshot>
                source =
                snapshot.Players;

            var players =
                new PlayerSnapshotData[
                    source.Count];

            for (int i = 0;
                 i < source.Count;
                 i++)
            {
                PlayerSnapshot player =
                    source[i];

                players[i] =
                    new PlayerSnapshotData
                    {
                        PlayerId =
                            player.PlayerId
                                .Value
                                .ToString(),

                        Vitality =
                            player.Vitality,

                        IsAlive =
                            player.IsAlive,

                        PositionX =
                            player.Position.X,

                        PositionY =
                            player.Position.Y
                    };
            }

            return new CoreSnapshotBroadcast
            {
                SessionId =
                    sessionId.Value.ToString(),

                ServerTick =
                    snapshot.Tick.Value,

                StateRevision =
                    snapshot.Revision.Value,

                Match =
                    new MatchSnapshotData
                    {
                        Lifecycle =
                            (byte)
                            snapshot.Match.Lifecycle,

                        ConnectedPlayers =
                            snapshot.Match
                                .ConnectedPlayers,

                        MaximumPlayers =
                            snapshot.Match
                                .MaximumPlayers,

                        Revision =
                            snapshot.Match
                                .Revision.Value
                    },

                Players =
                    players
            };
        }
    }
}
