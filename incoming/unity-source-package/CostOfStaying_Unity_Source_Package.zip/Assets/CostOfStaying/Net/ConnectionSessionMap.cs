using System.Collections.Generic;
using CostOfStaying.Core;

namespace CostOfStaying.Net
{
    public sealed class ConnectionSessionMap
    {
        private readonly Dictionary<
            int,
            SessionId>
            _sessions;

        public ConnectionSessionMap()
        {
            _sessions =
                new Dictionary<
                    int,
                    SessionId>();
        }

        public int Count =>
            _sessions.Count;

        public IEnumerable<KeyValuePair<int, SessionId>> Entries =>
            _sessions;

        public Result Bind(
            int clientId,
            SessionId sessionId)
        {
            if (clientId < 0)
            {
                return Result.Failure(
                    "connection.client_id_invalid");
            }

            if (sessionId.IsEmpty)
            {
                return Result.Failure(
                    "connection.session_empty");
            }

            if (_sessions.ContainsKey(
                    clientId))
            {
                return Result.Failure(
                    "connection.already_bound");
            }

            _sessions.Add(
                clientId,
                sessionId);

            return Result.Success();
        }

        public bool TryGet(
            int clientId,
            out SessionId sessionId)
        {
            return _sessions.TryGetValue(
                clientId,
                out sessionId);
        }

        public Result Remove(
            int clientId)
        {
            if (!_sessions.Remove(
                    clientId))
            {
                return Result.Failure(
                    "connection.not_bound");
            }

            return Result.Success();
        }

        public void Clear()
        {
            _sessions.Clear();
        }
    }
}
