using FishNet;
using FishNet.Connection;
using FishNet.Transporting;

namespace CostOfStaying.Net
{
    public sealed class FishNetServerRejectPublisher :
        IServerRejectPublisher
    {
        public void Reject(
            NetworkConnection connection,
            string code,
            long serverTick)
        {
            if (connection == null ||
                InstanceFinder.ServerManager == null)
            {
                return;
            }

            var message =
                new CoreRejectBroadcast
                {
                    Code =
                        code ?? string.Empty,

                    ServerTick =
                        serverTick
                };

            InstanceFinder.ServerManager
                .Broadcast(
                    connection,
                    message,
                    true,
                    Channel.Reliable);
        }
    }
}
