namespace CostOfStaying.Net
{
    public interface IServerConnectionRejector
    {
        void Reject(
            int clientId,
            string code);
    }
}
