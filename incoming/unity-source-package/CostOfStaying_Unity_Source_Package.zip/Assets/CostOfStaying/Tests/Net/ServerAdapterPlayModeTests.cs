using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace CostOfStaying.Tests
{
    public sealed class ServerAdapterPlayModeTests
    {
        [UnityTest]
        public IEnumerator ServerAdapterCanBeCreatedOnce()
        {
            GameObject gameObject =
                new GameObject(
                    "ServerAdapterTest");

            try
            {
                FishNetServerAdapter adapter =
                    gameObject.AddComponent<
                        FishNetServerAdapter>();

                Assert.That(
                    adapter,
                    Is.Not.Null);

                yield return null;
            }
            finally
            {
                Object.Destroy(
                    gameObject);
            }
        }
    }
}
