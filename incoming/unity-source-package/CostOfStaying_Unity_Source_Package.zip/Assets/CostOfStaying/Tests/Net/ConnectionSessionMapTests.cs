using System;
using CostOfStaying.Core;
using CostOfStaying.Net;
using NUnit.Framework;

namespace CostOfStaying.Tests
{
    [TestFixture]
    public sealed class ConnectionSessionMapTests
    {
        [Test]
        public void BindStoresSession()
        {
            var map =
                new ConnectionSessionMap();

            SessionId session =
                SessionId.TryCreate(
                    Guid.NewGuid()).Value;

            Result result =
                map.Bind(
                    10,
                    session);

            Assert.That(
                result.IsSuccess,
                Is.True);

            Assert.That(
                map.TryGet(
                    10,
                    out SessionId actual),
                Is.True);

            Assert.That(
                actual,
                Is.EqualTo(session));
        }

        [Test]
        public void DuplicateBindIsRejected()
        {
            var map =
                new ConnectionSessionMap();

            SessionId first =
                SessionId.TryCreate(
                    Guid.NewGuid()).Value;

            SessionId second =
                SessionId.TryCreate(
                    Guid.NewGuid()).Value;

            map.Bind(
                10,
                first);

            Result result =
                map.Bind(
                    10,
                    second);

            Assert.That(
                result.IsSuccess,
                Is.False);

            Assert.That(
                result.ErrorCode,
                Is.EqualTo(
                    "connection.already_bound"));
        }

        [Test]
        public void RemoveDeletesSession()
        {
            var map =
                new ConnectionSessionMap();

            SessionId session =
                SessionId.TryCreate(
                    Guid.NewGuid()).Value;

            map.Bind(
                10,
                session);

            Assert.That(
                map.Remove(
                    10).IsSuccess,
                Is.True);

            Assert.That(
                map.TryGet(
                    10,
                    out _),
                Is.False);
        }
    }
}
