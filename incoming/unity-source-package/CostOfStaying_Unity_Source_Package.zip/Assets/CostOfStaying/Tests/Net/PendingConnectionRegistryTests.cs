using CostOfStaying.Net;
using NUnit.Framework;

namespace CostOfStaying.Tests
{
    [TestFixture]
    public sealed class PendingConnectionRegistryTests
    {
        [Test]
        public void AddMarksConnectionPending()
        {
            var pending =
                new PendingConnectionRegistry();

            Assert.That(
                pending.Add(3),
                Is.True);

            Assert.That(
                pending.Contains(3),
                Is.True);
        }

        [Test]
        public void DuplicateAddIsRejected()
        {
            var pending =
                new PendingConnectionRegistry();

            pending.Add(3);

            Assert.That(
                pending.Add(3),
                Is.False);
        }

        [Test]
        public void RemoveClearsConnection()
        {
            var pending =
                new PendingConnectionRegistry();

            pending.Add(3);
            pending.Remove(3);

            Assert.That(
                pending.Contains(3),
                Is.False);
        }
    }
}
