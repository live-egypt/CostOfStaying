using CostOfStaying.Net;
using NUnit.Framework;

namespace CostOfStaying.Tests
{
    [TestFixture]
    public sealed class ClientAdapterStateTests
    {
        [Test]
        public void SequencesAreIndependent()
        {
            var state =
                new ClientAdapterState();

            Assert.That(
                state.NextMovementSequence(),
                Is.EqualTo(0));

            Assert.That(
                state.NextMovementSequence(),
                Is.EqualTo(1));

            Assert.That(
                state.NextBetrayalSequence(),
                Is.EqualTo(0));
        }

        [Test]
        public void ResetRestartsSequences()
        {
            var state =
                new ClientAdapterState();

            state.NextMovementSequence();
            state.NextBetrayalSequence();
            state.ResetSession();

            Assert.That(
                state.NextMovementSequence(),
                Is.EqualTo(0));

            Assert.That(
                state.NextBetrayalSequence(),
                Is.EqualTo(0));
        }
    }
}
