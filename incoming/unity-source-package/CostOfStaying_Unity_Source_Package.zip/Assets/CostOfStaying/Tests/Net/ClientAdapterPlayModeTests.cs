using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace CostOfStaying.Tests
{
    public sealed class ClientAdapterPlayModeTests
    {
        [UnityTest]
        public IEnumerator ClientAdapterCanBeCreated()
        {
            GameObject gameObject =
                new GameObject(
                    "ClientAdapterTest");

            try
            {
                FishNetClientAdapter adapter =
                    gameObject.AddComponent<
                        FishNetClientAdapter>();

                Assert.That(
                    adapter,
                    Is.Not.Null);

                yield return null;
            }
            finally
            {
                Object.Destroy(
                    gameObject);
            }
        }
    }
}
