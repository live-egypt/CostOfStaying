using System;
using CostOfStaying.Core;
using CostOfStaying.Net;
using NUnit.Framework;

namespace CostOfStaying.Tests
{
    [TestFixture]
    public sealed class CoreServerCommandIngressTests
    {
        [Test]
        public void NegativeMovementSequenceIsRejected()
        {
            CoreComposition core =
                CreateCore();

            var ingress =
                new CoreServerCommandIngress(
                    core);

            SessionId session =
                SessionId.TryCreate(
                    Guid.NewGuid()).Value;

            Result result =
                ingress.EnqueueMovement(
                    session,
                    new MovementInput(
                        0,
                        0,
                        false),
                    -1,
                    0);

            Assert.That(
                result.IsSuccess,
                Is.False);

            Assert.That(
                result.ErrorCode,
                Is.EqualTo(
                    "command.sequence_invalid"));
        }

        [Test]
        public void EmptyVictimIsRejected()
        {
            CoreComposition core =
                CreateCore();

            var ingress =
                new CoreServerCommandIngress(
                    core);

            SessionId session =
                SessionId.TryCreate(
                    Guid.NewGuid()).Value;

            Result result =
                ingress.EnqueueBetrayal(
                    session,
                    default,
                    0,
                    0);

            Assert.That(
                result.IsSuccess,
                Is.False);

            Assert.That(
                result.ErrorCode,
                Is.EqualTo(
                    "command.victim_empty"));
        }

        private static CoreComposition
            CreateCore()
        {
            Result<CoreComposition> result =
                CoreComposition.Create(
                    new MatchRules(
                        4,
                        100,
                        new CommandQueueOptions(
                            16,
                            2),
                        new BetrayalRules(
                            10,
                            10,
                            false,
                            true)),
                    new MovementRules(
                        4f,
                        6f,
                        0.05f),
                    0.05d,
                    new CommandAdmissionRules(
                        64,
                        0));

            Assert.That(
                result.IsSuccess,
                Is.True);

            return result.Value;
        }
    }
}
