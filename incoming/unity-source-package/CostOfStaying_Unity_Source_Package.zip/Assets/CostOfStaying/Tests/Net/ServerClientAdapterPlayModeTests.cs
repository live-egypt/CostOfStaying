using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace CostOfStaying.Tests
{
    public sealed class ServerClientAdapterPlayModeTests
    {
        [UnityTest]
        public IEnumerator ClientCommandReachesServer()
        {
            GameObject serverObject =
                new GameObject(
                    "ServerAdapter");

            GameObject clientObject =
                new GameObject(
                    "ClientAdapter");

            try
            {
                yield return null;

                Assert.That(
                    serverObject,
                    Is.Not.Null);

                Assert.That(
                    clientObject,
                    Is.Not.Null);

                // TODO:
                // 1. Start FishNet server.
                // 2. Start FishNet client.
                // 3. Wait for authentication.
                // 4. Send movement.
                // 5. Wait for server tick.
                // 6. Assert snapshot revision increased.
            }
            finally
            {
                Object.Destroy(
                    serverObject);

                Object.Destroy(
                    clientObject);
            }
        }
    }
}
