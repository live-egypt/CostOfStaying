using System;
using CostOfStaying.Core;
using CostOfStaying.Net;
using NUnit.Framework;

namespace CostOfStaying.Tests
{
    [TestFixture]
    public sealed class ClientProjectionStateTests
    {
        [Test]
        public void FirstSnapshotSetsSession()
        {
            var projection =
                new ClientProjectionState();

            string session =
                Guid.NewGuid().ToString();

            Result result =
                projection.Apply(
                    new CoreSnapshotBroadcast
                    {
                        SessionId =
                            session,

                        ServerTick =
                            10,

                        StateRevision =
                            4,

                        Players =
                            Array.Empty<
                                PlayerSnapshotData>()
                    });

            Assert.That(
                result.IsSuccess,
                Is.True);

            Assert.That(
                projection.SessionId,
                Is.EqualTo(session));
        }

        [Test]
        public void OlderSnapshotIsRejected()
        {
            var projection =
                new ClientProjectionState();

            string session =
                Guid.NewGuid().ToString();

            projection.Apply(
                new CoreSnapshotBroadcast
                {
                    SessionId =
                        session,

                    ServerTick =
                        10,

                    StateRevision =
                        4,

                    Players =
                        Array.Empty<
                            PlayerSnapshotData>()
                });

            Result result =
                projection.Apply(
                    new CoreSnapshotBroadcast
                    {
                        SessionId =
                            session,

                        ServerTick =
                            9,

                        StateRevision =
                            3,

                        Players =
                            Array.Empty<
                                PlayerSnapshotData>()
                    });

            Assert.That(
                result.IsSuccess,
                Is.False);
        }

        [Test]
        public void DifferentSessionIsRejected()
        {
            var projection =
                new ClientProjectionState();

            projection.Apply(
                new CoreSnapshotBroadcast
                {
                    SessionId =
                        Guid.NewGuid().ToString(),

                    ServerTick =
                        1,

                    StateRevision =
                        1,

                    Players =
                        Array.Empty<
                            PlayerSnapshotData>()
                });

            Result result =
                projection.Apply(
                    new CoreSnapshotBroadcast
                    {
                        SessionId =
                            Guid.NewGuid().ToString(),

                        ServerTick =
                            2,

                        StateRevision =
                            2,

                        Players =
                            Array.Empty<
                                PlayerSnapshotData>()
                    });

            Assert.That(
                result.IsSuccess,
                Is.False);
        }
    }
}
