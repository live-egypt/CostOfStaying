using System;
using CostOfStaying.Core;
using NUnit.Framework;

namespace CostOfStaying.Tests
{
    [TestFixture]
    public sealed class CommandSequenceTrackerTests
    {
        [Test]
        public void MovementAndBetrayalSequencesAreIndependent()
        {
            var tracker =
                new CommandSequenceTracker();

            SessionId session =
                SessionId.TryCreate(
                    Guid.NewGuid()).Value;

            Assert.That(
                tracker.ValidateMovement(
                    session,
                    4).IsSuccess,
                Is.True);

            Assert.That(
                tracker.ValidateBetrayal(
                    session,
                    0).IsSuccess,
                Is.True);
        }

        [Test]
        public void ReplayedSequenceIsRejected()
        {
            var tracker =
                new CommandSequenceTracker();

            SessionId session =
                SessionId.TryCreate(
                    Guid.NewGuid()).Value;

            tracker.ValidateMovement(
                session,
                3);

            Assert.That(
                tracker.ValidateMovement(
                    session,
                    3).IsSuccess,
                Is.False);

            Assert.That(
                tracker.ValidateMovement(
                    session,
                    2).IsSuccess,
                Is.False);
        }


        [Test]
        public void ExcessiveFutureSequenceJumpIsRejectedWithoutAdvancingTracker()
        {
            var tracker = new CommandSequenceTracker(4);
            SessionId session = SessionId.TryCreate(Guid.NewGuid()).Value;

            Assert.That(tracker.ValidateMovement(session, 0).IsSuccess, Is.True);
            Result rejected = tracker.ValidateMovement(session, 5);

            Assert.That(rejected.IsSuccess, Is.False);
            Assert.That(rejected.ErrorCode, Is.EqualTo("command.movement_sequence_jump"));
            Assert.That(tracker.ValidateMovement(session, 1).IsSuccess, Is.True);
        }

        [Test]
        public void NewerSequenceIsAccepted()
        {
            var tracker =
                new CommandSequenceTracker();

            SessionId session =
                SessionId.TryCreate(
                    Guid.NewGuid()).Value;

            Assert.That(
                tracker.ValidateMovement(
                    session,
                    0).IsSuccess,
                Is.True);

            Assert.That(
                tracker.ValidateMovement(
                    session,
                    1).IsSuccess,
                Is.True);
        }
    }
}
