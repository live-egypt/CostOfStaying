using System;
using CostOfStaying.Core;
using NUnit.Framework;

namespace CostOfStaying.Tests
{
    [TestFixture]
    public sealed class CoreCompositionTests
    {
        [Test]
        public void CompositionCanBeCreated()
        {
            Result<CoreComposition> result =
                CoreComposition.Create(
                    CreateRules(),
                    new MovementRules(
                        4f,
                        6f,
                        0.05f),
                    0.05d,
                    new CommandAdmissionRules(
                        2,
                        0));

            Assert.That(
                result.IsSuccess,
                Is.True);

            Assert.That(
                result.Value,
                Is.Not.Null);
        }

        [Test]
        public void TickCannotMoveBackwards()
        {
            var ticks =
                new CoreTickState();

            Assert.That(
                ticks.AdvanceTo(
                    new ServerTick(5))
                    .IsSuccess,
                Is.True);

            Assert.That(
                ticks.AdvanceTo(
                    new ServerTick(4))
                    .IsSuccess,
                Is.False);

            Assert.That(
                ticks.Current.Value,
                Is.EqualTo(5));
        }

        [Test]
        public void DuplicatePlayerSessionIsRejected()
        {
            var sessions =
                new SessionRepository();

            PlayerId player =
                PlayerId.TryCreate(
                    Guid.NewGuid()).Value;

            PlayerSession first =
                new PlayerSession(
                    SessionId.New(),
                    player,
                    1);

            PlayerSession second =
                new PlayerSession(
                    SessionId.New(),
                    player,
                    2);

            Assert.That(
                sessions.Add(first)
                    .IsSuccess,
                Is.True);

            Assert.That(
                sessions.Add(second)
                    .IsSuccess,
                Is.False);
        }

        [Test]
        public void MovementInputIsClamped()
        {
            var input =
                new MovementInput(
                    3000,
                    -3000,
                    false);

            Assert.That(
                input.Horizontal,
                Is.EqualTo(1000));

            Assert.That(
                input.Vertical,
                Is.EqualTo(-1000));
        }

        private static MatchRules
            CreateRules()
        {
            return new MatchRules(
                16,
                100,
                new CommandQueueOptions(
                    128,
                    2),
                new BetrayalRules(
                    20,
                    25,
                    false,
                    true));
        }
    }
}
