using System;
using CostOfStaying.Core;
using NUnit.Framework;

namespace CostOfStaying.Tests
{
    [TestFixture]
    public sealed class PlayerStateTests
    {
        [Test]
        public void DamageCannotReduceVitalityBelowZero()
        {
            PlayerId id =
                PlayerId.TryCreate(
                    Guid.NewGuid()).Value;

            var player =
                new PlayerState(
                    id,
                    10,
                    new Position2(0f, 0f));

            player.ApplyDamage(20);

            Assert.That(
                player.Vitality,
                Is.EqualTo(0));

            Assert.That(
                player.IsAlive,
                Is.False);
        }

        [Test]
        public void NegativeDamageIsRejected()
        {
            PlayerId id =
                PlayerId.TryCreate(
                    Guid.NewGuid()).Value;

            var player =
                new PlayerState(
                    id,
                    10,
                    new Position2(0f, 0f));

            Assert.That(
                player.ApplyDamage(-1)
                    .IsSuccess,
                Is.False);

            Assert.That(
                player.Vitality,
                Is.EqualTo(10));
        }
    }
}
