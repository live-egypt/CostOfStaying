using CostOfStaying.Core;
using NUnit.Framework;

namespace CostOfStaying.Tests
{
    [TestFixture]
    public sealed class MatchStateTests
    {
        [Test]
        public void MatchRejectsPlayersAfterCapacity()
        {
            var match =
                new MatchState(1);

            Assert.That(
                match.AddPlayer()
                    .IsSuccess,
                Is.True);

            Assert.That(
                match.AddPlayer()
                    .IsSuccess,
                Is.False);

            Assert.That(
                match.ConnectedPlayers,
                Is.EqualTo(1));
        }

        [Test]
        public void MatchCanStartAfterPlayerJoins()
        {
            var match =
                new MatchState(2);

            match.AddPlayer();

            Assert.That(
                match.Start()
                    .IsSuccess,
                Is.True);

            Assert.That(
                match.Lifecycle,
                Is.EqualTo(
                    MatchLifecycleState.Running));
        }
    }
}
