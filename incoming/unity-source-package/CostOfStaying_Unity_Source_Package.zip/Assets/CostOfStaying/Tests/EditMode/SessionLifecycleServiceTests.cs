using System;
using CostOfStaying.Core;
using NUnit.Framework;

namespace CostOfStaying.Tests
{
    [TestFixture]
    public sealed class SessionLifecycleServiceTests
    {
        [Test]
        public void ConnectCreatesUnauthenticatedSession()
        {
            var sessions =
                new SessionRepository();

            var presence =
                new PresenceState();

            var participation =
                new ParticipationState();

            var authoritative =
                new AuthoritativeState(4);

            var service =
                new SessionLifecycleService(
                    sessions,
                    presence,
                    participation,
                    authoritative,
                    100);

            PlayerId player =
                PlayerId.TryCreate(
                    Guid.NewGuid()).Value;

            Result<PlayerSession> result =
                service.Connect(
                    player,
                    10,
                    new ServerTick(1));

            Assert.That(
                result.IsSuccess,
                Is.True);

            Assert.That(
                result.Value.IsConnected,
                Is.True);

            Assert.That(
                result.Value.IsAuthenticated,
                Is.False);

            Assert.That(
                presence.IsOnline(player),
                Is.True);
        }

        [Test]
        public void DisconnectRemovesPresenceAndSession()
        {
            var sessions =
                new SessionRepository();

            var presence =
                new PresenceState();

            var participation =
                new ParticipationState();

            var authoritative =
                new AuthoritativeState(4);

            var service =
                new SessionLifecycleService(
                    sessions,
                    presence,
                    participation,
                    authoritative,
                    100);

            PlayerId player =
                PlayerId.TryCreate(
                    Guid.NewGuid()).Value;

            PlayerSession session =
                service.Connect(
                    player,
                    10,
                    new ServerTick(1)).Value;

            Result result =
                service.Disconnect(
                    session.SessionId);

            Assert.That(
                result.IsSuccess,
                Is.True);

            Assert.That(
                presence.IsOnline(player),
                Is.False);

            Assert.That(
                sessions.Count,
                Is.EqualTo(0));

            Assert.That(
                authoritative.Players.Count,
                Is.EqualTo(0));

            Assert.That(
                authoritative.Match.ConnectedPlayers,
                Is.EqualTo(0));
        }
    }
}
