namespace CostOfStaying.Core
{
    public readonly struct StateRevision
    {
        public long Value {
            get;
        }

        public StateRevision(
            long value)
        {
            Value =
                value < 0
                    ? 0
                    : value;
        }

        public StateRevision Next()
        {
            return new StateRevision(
                Value + 1);
        }

        public override string ToString()
        {
            return Value.ToString();
        }
    }
}
