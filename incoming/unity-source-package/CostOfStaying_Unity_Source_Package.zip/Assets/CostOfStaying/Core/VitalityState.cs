using System.Collections.Generic;

namespace CostOfStaying.Core
{
    public sealed class VitalityState
    {
        private readonly Dictionary<
            PlayerId,
            int>
            _values;

        private readonly int
            _startingValue;

        public VitalityState(
            int startingValue)
        {
            _startingValue =
                startingValue < 0
                    ? 0
                    : startingValue;

            _values =
                new Dictionary<
                    PlayerId,
                    int>();
        }

        public int Get(
            PlayerId playerId)
        {
            if (!_values.TryGetValue(
                    playerId,
                    out int value))
            {
                return _startingValue;
            }

            return value;
        }

        public void Ensure(
            PlayerId playerId)
        {
            if (!_values.ContainsKey(
                    playerId))
            {
                _values.Add(
                    playerId,
                    _startingValue);
            }
        }

        public Result ApplyDamage(
            PlayerId playerId,
            int damage)
        {
            if (damage < 0)
            {
                return Result.Failure(
                    "vitality.damage_negative");
            }

            Ensure(
                playerId);

            int current =
                _values[playerId];

            int next =
                current - damage;

            _values[playerId] =
                next < 0
                    ? 0
                    : next;

            return Result.Success();
        }

        public bool IsAlive(
            PlayerId playerId)
        {
            return Get(
                playerId) > 0;
        }
    }
}
