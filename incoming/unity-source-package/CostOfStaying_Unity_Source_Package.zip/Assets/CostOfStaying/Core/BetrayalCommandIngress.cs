using System.Collections.Generic;

namespace CostOfStaying.Core
{
    public sealed class BetrayalCommandIngress
    {
        private readonly Queue<
            BetrayalCommand>
            _commands;

        private readonly CommandQueueOptions
            _options;

        public BetrayalCommandIngress(
            CommandQueueOptions options)
        {
            _options =
                options;

            _commands =
                new Queue<
                    BetrayalCommand>();
        }

        public Result Enqueue(
            BetrayalCommand command,
            ServerTick currentTick)
        {
            if (_commands.Count >=
                _options.MaximumCommandsPerTick *
                4)
            {
                return Result.Failure(
                    "betrayal.queue_full");
            }

            long delta =
                currentTick.Value -
                command.Envelope.RequestedTick.Value;

            if (delta >
                _options.MaximumLateTicks)
            {
                return Result.Failure(
                    "betrayal.command_too_old");
            }

            _commands.Enqueue(
                command);

            return Result.Success();
        }

        public bool TryDequeue(
            out BetrayalCommand command)
        {
            if (_commands.Count == 0)
            {
                command =
                    default;

                return false;
            }

            command =
                _commands.Dequeue();

            return true;
        }

        public int Count =>
            _commands.Count;
    }
}
