using System.Collections.Generic;

namespace CostOfStaying.Core
{
    public sealed class CorePipelineResult
    {
        private readonly List<CommandOutcome>
            _outcomes;

        public IReadOnlyList<CommandOutcome>
            Outcomes =>
            _outcomes;

        public CorePipelineResult()
        {
            _outcomes =
                new List<CommandOutcome>();
        }

        public void Add(
            CommandOutcome outcome)
        {
            _outcomes.Add(
                outcome);
        }
    }
}
