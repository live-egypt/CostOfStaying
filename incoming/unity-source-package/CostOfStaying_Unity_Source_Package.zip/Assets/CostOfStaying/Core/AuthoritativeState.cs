namespace CostOfStaying.Core
{
    public sealed class AuthoritativeState
    {
        public MatchState Match {
            get;
        }

        public PlayerStateRepository Players {
            get;
        }

        public StateRevision Revision {
            get;
            private set;
        }

        public AuthoritativeState(
            int maximumPlayers)
        {
            Match =
                new MatchState(
                    maximumPlayers);

            Players =
                new PlayerStateRepository();

            Revision =
                new StateRevision(0);
        }

        public void MarkChanged()
        {
            Revision =
                Revision.Next();
        }
    }
}
