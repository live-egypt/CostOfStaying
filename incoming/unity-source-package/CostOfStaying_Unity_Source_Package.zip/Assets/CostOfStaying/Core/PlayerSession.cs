namespace CostOfStaying.Core
{
    public sealed class PlayerSession
    {
        public SessionId SessionId {
            get;
        }

        public PlayerId PlayerId {
            get;
        }

        public int ClientId {
            get;
        }

        public bool IsConnected {
            get;
            private set;
        }

        public bool IsAuthenticated {
            get;
            private set;
        }

        public PlayerSession(
            SessionId sessionId,
            PlayerId playerId,
            int clientId)
        {
            SessionId =
                sessionId;

            PlayerId =
                playerId;

            ClientId =
                clientId;

            IsConnected =
                true;

            IsAuthenticated =
                false;
        }

        public Result Authenticate()
        {
            if (!IsConnected)
            {
                return Result.Failure(
                    "session.not_connected");
            }

            IsAuthenticated =
                true;

            return Result.Success();
        }

        public Result Disconnect()
        {
            IsConnected =
                false;

            IsAuthenticated =
                false;

            return Result.Success();
        }
    }
}
