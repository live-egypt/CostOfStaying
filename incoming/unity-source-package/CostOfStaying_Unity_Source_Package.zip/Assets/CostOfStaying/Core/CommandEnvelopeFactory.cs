namespace CostOfStaying.Core
{
    public sealed class CommandEnvelopeFactory
    {
        private readonly CommandAdmissionRules
            _rules;

        private readonly CoreTickState
            _ticks;

        public CommandEnvelopeFactory(
            CommandAdmissionRules rules,
            CoreTickState ticks)
        {
            _rules =
                rules;

            _ticks =
                ticks;
        }

        public Result<CommandEnvelope> Create(
            SessionId sessionId,
            int clientId,
            long clientSequence,
            ServerTick requestedTick)
        {
            if (sessionId.IsEmpty)
            {
                return Result<CommandEnvelope>.Failure(
                    "command.session_empty");
            }

            if (clientSequence < 0)
            {
                return Result<CommandEnvelope>.Failure(
                    "command.sequence_invalid");
            }

            if (requestedTick.Value <
                _rules.MinimumRequestedTick)
            {
                return Result<CommandEnvelope>.Failure(
                    "command.tick_below_minimum");
            }

            return Result<CommandEnvelope>.Success(
                new CommandEnvelope(
                    sessionId,
                    clientId,
                    clientSequence,
                    requestedTick));
        }
    }
}
