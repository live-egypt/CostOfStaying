using System.Collections.Generic;

namespace CostOfStaying.Core
{
    public sealed class PlayerStateRepository
    {
        private readonly Dictionary<
            PlayerId,
            PlayerState>
            _players =
            new Dictionary<
                PlayerId,
                PlayerState>();

        public IEnumerable<PlayerId> Ids =>
            _players.Keys;

        public int Count =>
            _players.Count;

        public Result Add(
            PlayerState player)
        {
            if (player == null)
            {
                return Result.Failure(
                    "player.null");
            }

            if (_players.ContainsKey(
                    player.PlayerId))
            {
                return Result.Failure(
                    "player.duplicate");
            }

            _players.Add(
                player.PlayerId,
                player);

            return Result.Success();
        }

        public bool TryGet(
            PlayerId id,
            out PlayerState player)
        {
            return _players.TryGetValue(
                id,
                out player);
        }

        public Result Remove(
            PlayerId id)
        {
            if (!_players.Remove(
                    id))
            {
                return Result.Failure(
                    "player.not_found");
            }

            return Result.Success();
        }

        public void Clear()
        {
            _players.Clear();
        }
    }
}
