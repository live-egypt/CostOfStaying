namespace CostOfStaying.Core
{
    public readonly struct CommandEnvelope
    {
        public SessionId SessionId {
            get;
        }

        public int ClientId {
            get;
        }

        public long ClientSequence {
            get;
        }

        public ServerTick RequestedTick {
            get;
        }

        public CommandEnvelope(
            SessionId sessionId,
            int clientId,
            long clientSequence,
            ServerTick requestedTick)
        {
            SessionId =
                sessionId;

            ClientId =
                clientId;

            ClientSequence =
                clientSequence;

            RequestedTick =
                requestedTick;
        }
    }
}
