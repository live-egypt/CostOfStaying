using System.Collections.Generic;

namespace CostOfStaying.Core
{
    public sealed class CoreSnapshot
    {
        private readonly
            IReadOnlyList<PlayerSnapshot>
            _players;

        public ServerTick Tick {
            get;
        }

        public StateRevision Revision {
            get;
        }

        public MatchSnapshot Match {
            get;
        }

        public IReadOnlyList<PlayerSnapshot>
            Players =>
            _players;

        public CoreSnapshot(
            ServerTick tick,
            StateRevision revision,
            MatchSnapshot match,
            IReadOnlyList<PlayerSnapshot>
                players)
        {
            Tick =
                tick;

            Revision =
                revision;

            Match =
                match;

            _players =
                players;
        }
    }
}
