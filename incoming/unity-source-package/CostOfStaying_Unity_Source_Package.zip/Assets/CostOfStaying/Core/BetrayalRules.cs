namespace CostOfStaying.Core
{
    public readonly struct BetrayalRules
    {
        public int VitalityDamage {
            get;
        }

        public int BetrayalCost {
            get;
        }

        public bool RequiresLineOfSight {
            get;
        }

        public bool RequiresAliveAttacker {
            get;
        }

        public BetrayalRules(
            int vitalityDamage,
            int betrayalCost,
            bool requiresLineOfSight,
            bool requiresAliveAttacker)
        {
            VitalityDamage =
                vitalityDamage < 0
                    ? 0
                    : vitalityDamage;

            BetrayalCost =
                betrayalCost < 0
                    ? 0
                    : betrayalCost;

            RequiresLineOfSight =
                requiresLineOfSight;

            RequiresAliveAttacker =
                requiresAliveAttacker;
        }
    }
}
