using System.Collections.Generic;

namespace CostOfStaying.Core
{
    public sealed class ParticipationState
    {
        private readonly HashSet<PlayerId>
            _participants;

        public ParticipationState()
        {
            _participants =
                new HashSet<PlayerId>();
        }

        public bool Contains(
            PlayerId playerId)
        {
            return _participants.Contains(
                playerId);
        }

        public Result Add(
            PlayerId playerId)
        {
            if (!_participants.Add(
                    playerId))
            {
                return Result.Failure(
                    "participation.already_added");
            }

            return Result.Success();
        }

        public Result Remove(
            PlayerId playerId)
        {
            if (!_participants.Remove(
                    playerId))
            {
                return Result.Failure(
                    "participation.not_found");
            }

            return Result.Success();
        }

        public int Count =>
            _participants.Count;
    }
}
