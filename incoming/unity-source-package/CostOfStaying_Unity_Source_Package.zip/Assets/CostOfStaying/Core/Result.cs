namespace CostOfStaying.Core
{
    public readonly struct Result
    {
        public bool IsSuccess {
            get;
        }

        public string ErrorCode {
            get;
        }

        private Result(
            bool isSuccess,
            string errorCode)
        {
            IsSuccess =
                isSuccess;

            ErrorCode =
                errorCode ?? string.Empty;
        }

        public static Result Success()
        {
            return new Result(
                true,
                string.Empty);
        }

        public static Result Failure(
            string errorCode)
        {
            return new Result(
                false,
                errorCode);
        }
    }

    public readonly struct Result<T>
    {
        public bool IsSuccess {
            get;
        }

        public string ErrorCode {
            get;
        }

        public T Value {
            get;
        }

        private Result(
            bool isSuccess,
            T value,
            string errorCode)
        {
            IsSuccess =
                isSuccess;

            Value =
                value;

            ErrorCode =
                errorCode ?? string.Empty;
        }

        public static Result<T> Success(
            T value)
        {
            return new Result<T>(
                true,
                value,
                string.Empty);
        }

        public static Result<T> Failure(
            string errorCode)
        {
            return new Result<T>(
                false,
                default,
                errorCode);
        }
    }
}
