using System.Collections.Generic;

namespace CostOfStaying.Core
{
    public readonly struct Position2
    {
        public float X {
            get;
        }

        public float Y {
            get;
        }

        public Position2(
            float x,
            float y)
        {
            X =
                x;

            Y =
                y;
        }

        public Position2 Add(
            float x,
            float y)
        {
            return new Position2(
                X + x,
                Y + y);
        }
    }

    public sealed class MovementState
    {
        private readonly Dictionary<
            PlayerId,
            Position2>
            _positions;

        public MovementState()
        {
            _positions =
                new Dictionary<
                    PlayerId,
                    Position2>();
        }

        public Position2 Get(
            PlayerId playerId)
        {
            if (!_positions.TryGetValue(
                    playerId,
                    out Position2 position))
            {
                return new Position2(
                    0f,
                    0f);
            }

            return position;
        }

        public void Set(
            PlayerId playerId,
            Position2 position)
        {
            _positions[playerId] =
                position;
        }
    }
}
