using System.Collections.Generic;

namespace CostOfStaying.Core
{
    public sealed class CommandSequenceTracker
    {
        private readonly Dictionary<
            SessionId,
            long>
            _movement;

        private readonly Dictionary<
            SessionId,
            long>
            _betrayal;

        private readonly long _maximumSequenceJump;

        public CommandSequenceTracker(
            long maximumSequenceJump = long.MaxValue)
        {
            _maximumSequenceJump =
                maximumSequenceJump < 0
                    ? 0
                    : maximumSequenceJump;
            _movement =
                new Dictionary<
                    SessionId,
                    long>();

            _betrayal =
                new Dictionary<
                    SessionId,
                    long>();
        }

        public Result ValidateMovement(
            SessionId sessionId,
            long sequence)
        {
            return ValidateAndRecord(
                _movement,
                sessionId,
                sequence,
                "movement");
        }

        public Result ValidateBetrayal(
            SessionId sessionId,
            long sequence)
        {
            return ValidateAndRecord(
                _betrayal,
                sessionId,
                sequence,
                "betrayal");
        }

        public void Remove(
            SessionId sessionId)
        {
            _movement.Remove(
                sessionId);

            _betrayal.Remove(
                sessionId);
        }

        public void Clear()
        {
            _movement.Clear();
            _betrayal.Clear();
        }

        private Result
            ValidateAndRecord(
                Dictionary<
                    SessionId,
                    long>
                    values,
                SessionId sessionId,
                long sequence,
                string kind)
        {
            if (sessionId.IsEmpty)
            {
                return Result.Failure(
                    "command.session_empty");
            }

            if (sequence < 0)
            {
                return Result.Failure(
                    "command.sequence_invalid");
            }

            if (values.TryGetValue(
                    sessionId,
                    out long last))
            {
                if (sequence <= last)
                {
                    return Result.Failure(
                        "command." +
                        kind +
                        "_sequence_replayed");
                }

                if (sequence - last >
                    _maximumSequenceJump)
                {
                    return Result.Failure(
                        "command." +
                        kind +
                        "_sequence_jump");
                }
            }
            else if (sequence > _maximumSequenceJump)
            {
                return Result.Failure(
                    "command." +
                    kind +
                    "_sequence_jump");
            }

            values[sessionId] =
                sequence;

            return Result.Success();
        }
    }
}
