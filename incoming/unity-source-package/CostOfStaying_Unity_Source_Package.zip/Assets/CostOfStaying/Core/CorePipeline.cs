namespace CostOfStaying.Core
{
    public sealed class CorePipeline
    {
        private readonly CoreTickState
            _ticks;

        private readonly MovementCommandIngress
            _movementIngress;

        private readonly BetrayalCommandIngress
            _betrayalIngress;

        private readonly MovementService
            _movement;

        private readonly BetrayalService
            _betrayal;

        private readonly AuthoritativeState
            _state;

        private readonly CommandSequenceTracker
            _sequences;

        public CorePipeline(
            CoreTickState ticks,
            MovementCommandIngress movementIngress,
            BetrayalCommandIngress betrayalIngress,
            MovementService movement,
            BetrayalService betrayal,
            AuthoritativeState state,
            CommandSequenceTracker sequences)
        {
            _ticks =
                ticks;

            _movementIngress =
                movementIngress;

            _betrayalIngress =
                betrayalIngress;

            _movement =
                movement;

            _betrayal =
                betrayal;

            _state =
                state;

            _sequences =
                sequences;
        }

        public void RemoveSession(
            SessionId sessionId)
        {
            _sequences.Remove(sessionId);
        }

        public Result<CorePipelineResult> Execute(
            ServerTick tick)
        {
            Result advanced =
                _ticks.AdvanceTo(
                    tick);

            if (!advanced.IsSuccess)
            {
                return Result<CorePipelineResult>.Failure(
                    advanced.ErrorCode);
            }

            var output =
                new CorePipelineResult();

            while (_movementIngress.TryDequeue(
                       out MovementCommand movement))
            {
                Result sequence =
                    _sequences.ValidateMovement(
                        movement.Envelope.SessionId,
                        movement.Envelope.ClientSequence);

                if (!sequence.IsSuccess)
                {
                    output.Add(
                        CommandOutcome.Failure(
                            CommandKind.Movement,
                            movement.Envelope.ClientSequence,
                            sequence.ErrorCode,
                            tick));

                    continue;
                }

                Result executed =
                    _movement.Execute(
                        movement,
                        tick);

                output.Add(
                    executed.IsSuccess
                        ? CommandOutcome.Success(
                            CommandKind.Movement,
                            movement.Envelope.ClientSequence,
                            tick)
                        : CommandOutcome.Failure(
                            CommandKind.Movement,
                            movement.Envelope.ClientSequence,
                            executed.ErrorCode,
                            tick));
            }

            while (_betrayalIngress.TryDequeue(
                       out BetrayalCommand betrayal))
            {
                Result sequence =
                    _sequences.ValidateBetrayal(
                        betrayal.Envelope.SessionId,
                        betrayal.Envelope.ClientSequence);

                if (!sequence.IsSuccess)
                {
                    output.Add(
                        CommandOutcome.Failure(
                            CommandKind.Betrayal,
                            betrayal.Envelope.ClientSequence,
                            sequence.ErrorCode,
                            tick));

                    continue;
                }

                Result executed =
                    _betrayal.Execute(
                        betrayal,
                        tick);

                output.Add(
                    executed.IsSuccess
                        ? CommandOutcome.Success(
                            CommandKind.Betrayal,
                            betrayal.Envelope.ClientSequence,
                            tick)
                        : CommandOutcome.Failure(
                            CommandKind.Betrayal,
                            betrayal.Envelope.ClientSequence,
                            executed.ErrorCode,
                            tick));
            }

            return Result<CorePipelineResult>.Success(
                output);
        }
    }
}
