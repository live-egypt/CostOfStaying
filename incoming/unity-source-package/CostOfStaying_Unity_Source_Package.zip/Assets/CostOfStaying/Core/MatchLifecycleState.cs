namespace CostOfStaying.Core
{
    public enum MatchLifecycleState : byte
    {
        Waiting = 0,
        Running = 1,
        Finished = 2,
        Closed = 3
    }
}
