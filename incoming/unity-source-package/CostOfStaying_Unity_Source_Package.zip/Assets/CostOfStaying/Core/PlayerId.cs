using System;

namespace CostOfStaying.Core
{
    public readonly struct PlayerId :
        IEquatable<PlayerId>
    {
        public Guid Value {
            get;
        }

        public bool IsEmpty =>
            Value == Guid.Empty;

        private PlayerId(
            Guid value)
        {
            Value =
                value;
        }

        public static Result<PlayerId>
            TryCreate(
                Guid value)
        {
            if (value == Guid.Empty)
            {
                return Result<PlayerId>.Failure(
                    "player.id_empty");
            }

            return Result<PlayerId>.Success(
                new PlayerId(value));
        }

        public bool Equals(
            PlayerId other)
        {
            return Value.Equals(
                other.Value);
        }

        public override bool Equals(
            object obj)
        {
            return obj is PlayerId other &&
                   Equals(other);
        }

        public override int GetHashCode()
        {
            return Value.GetHashCode();
        }

        public override string ToString()
        {
            return Value.ToString();
        }

        public static bool operator ==(
            PlayerId left,
            PlayerId right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(
            PlayerId left,
            PlayerId right)
        {
            return !left.Equals(right);
        }
    }
}
