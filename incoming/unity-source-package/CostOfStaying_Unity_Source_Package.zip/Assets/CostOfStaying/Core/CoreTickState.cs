namespace CostOfStaying.Core
{
    public sealed class CoreTickState
    {
        public ServerTick Current {
            get;
            private set;
        }

        public CoreTickState()
        {
            Current =
                ServerTick.Zero;
        }

        public Result AdvanceTo(
            ServerTick tick)
        {
            if (tick.Value <
                Current.Value)
            {
                return Result.Failure(
                    "core.tick_backwards");
            }

            Current =
                tick;

            return Result.Success();
        }

        public void Advance()
        {
            Current =
                Current.Next();
        }
    }
}
