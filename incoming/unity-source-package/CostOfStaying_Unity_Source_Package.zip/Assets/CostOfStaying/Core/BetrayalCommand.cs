namespace CostOfStaying.Core
{
    public readonly struct BetrayalCommand
    {
        public CommandEnvelope Envelope {
            get;
        }

        public PlayerId VictimId {
            get;
        }

        public BetrayalCommand(
            CommandEnvelope envelope,
            PlayerId victimId)
        {
            Envelope =
                envelope;

            VictimId =
                victimId;
        }
    }
}
