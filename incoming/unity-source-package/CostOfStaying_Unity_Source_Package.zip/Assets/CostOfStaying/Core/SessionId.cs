using System;

namespace CostOfStaying.Core
{
    public readonly struct SessionId :
        IEquatable<SessionId>
    {
        public Guid Value {
            get;
        }

        public bool IsEmpty =>
            Value == Guid.Empty;

        private SessionId(
            Guid value)
        {
            Value =
                value;
        }

        public static SessionId New()
        {
            return new SessionId(
                Guid.NewGuid());
        }

        public static Result<SessionId>
            TryCreate(
                Guid value)
        {
            if (value == Guid.Empty)
            {
                return Result<SessionId>.Failure(
                    "session.id_empty");
            }

            return Result<SessionId>.Success(
                new SessionId(value));
        }

        public bool Equals(
            SessionId other)
        {
            return Value.Equals(
                other.Value);
        }

        public override bool Equals(
            object obj)
        {
            return obj is SessionId other &&
                   Equals(other);
        }

        public override int GetHashCode()
        {
            return Value.GetHashCode();
        }

        public override string ToString()
        {
            return Value.ToString();
        }

        public static bool operator ==(
            SessionId left,
            SessionId right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(
            SessionId left,
            SessionId right)
        {
            return !left.Equals(right);
        }
    }
}
