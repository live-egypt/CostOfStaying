namespace CostOfStaying.Core
{
    public sealed class PlayerState
    {
        public PlayerId PlayerId {
            get;
        }

        public int Vitality {
            get;
            private set;
        }

        public bool IsAlive =>
            Vitality > 0;

        public Position2 Position {
            get;
            private set;
        }

        public PlayerState(
            PlayerId playerId,
            int vitality,
            Position2 position)
        {
            PlayerId =
                playerId;

            Vitality =
                vitality < 0
                    ? 0
                    : vitality;

            Position =
                position;
        }

        public Result ApplyDamage(
            int damage)
        {
            if (damage < 0)
            {
                return Result.Failure(
                    "player.damage_negative");
            }

            Vitality -=
                damage;

            if (Vitality < 0)
            {
                Vitality =
                    0;
            }

            return Result.Success();
        }

        public void SetPosition(
            Position2 position)
        {
            Position =
                position;
        }
    }
}
