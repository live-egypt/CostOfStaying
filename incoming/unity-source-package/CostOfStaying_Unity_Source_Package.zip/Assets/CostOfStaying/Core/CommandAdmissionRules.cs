namespace CostOfStaying.Core
{
    public readonly struct CommandAdmissionRules
    {
        public long MaximumSequenceJump {
            get;
        }

        public long MinimumRequestedTick {
            get;
        }

        public CommandAdmissionRules(
            long maximumSequenceJump,
            long minimumRequestedTick)
        {
            MaximumSequenceJump =
                maximumSequenceJump < 0
                    ? 0
                    : maximumSequenceJump;

            MinimumRequestedTick =
                minimumRequestedTick < 0
                    ? 0
                    : minimumRequestedTick;
        }
    }
}
