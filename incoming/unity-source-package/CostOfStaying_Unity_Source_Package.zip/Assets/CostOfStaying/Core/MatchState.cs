namespace CostOfStaying.Core
{
    public sealed class MatchState
    {
        public MatchLifecycleState
            Lifecycle {
            get;
            private set;
        }

        public int MaximumPlayers {
            get;
        }

        public int ConnectedPlayers {
            get;
            private set;
        }

        public MatchState(
            int maximumPlayers)
        {
            MaximumPlayers =
                maximumPlayers <= 0
                    ? 1
                    : maximumPlayers;

            Lifecycle =
                MatchLifecycleState.Waiting;
        }

        public Result AddPlayer()
        {
            if (Lifecycle ==
                MatchLifecycleState.Closed)
            {
                return Result.Failure(
                    "match.closed");
            }

            if (Lifecycle ==
                MatchLifecycleState.Finished)
            {
                return Result.Failure(
                    "match.finished");
            }

            if (ConnectedPlayers >=
                MaximumPlayers)
            {
                return Result.Failure(
                    "match.full");
            }

            ConnectedPlayers++;

            return Result.Success();
        }

        public Result RemovePlayer()
        {
            if (ConnectedPlayers <= 0)
            {
                return Result.Failure(
                    "match.no_players");
            }

            ConnectedPlayers--;

            if (Lifecycle ==
                MatchLifecycleState.Running &&
                ConnectedPlayers == 0)
            {
                Lifecycle =
                    MatchLifecycleState.Waiting;
            }

            return Result.Success();
        }

        public Result Start()
        {
            if (Lifecycle !=
                MatchLifecycleState.Waiting)
            {
                return Result.Failure(
                    "match.not_waiting");
            }

            if (ConnectedPlayers <= 0)
            {
                return Result.Failure(
                    "match.no_players");
            }

            Lifecycle =
                MatchLifecycleState.Running;

            return Result.Success();
        }

        public Result Finish()
        {
            if (Lifecycle !=
                MatchLifecycleState.Running)
            {
                return Result.Failure(
                    "match.not_running");
            }

            Lifecycle =
                MatchLifecycleState.Finished;

            return Result.Success();
        }

        public Result Close()
        {
            Lifecycle =
                MatchLifecycleState.Closed;

            return Result.Success();
        }
    }
}
