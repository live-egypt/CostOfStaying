namespace CostOfStaying.Core
{
    public sealed class MovementService
    {
        private readonly SessionRepository
            _sessions;

        private readonly AuthoritativeState
            _state;

        private readonly MovementRules
            _rules;

        public MovementService(
            SessionRepository sessions,
            AuthoritativeState state,
            MovementRules rules)
        {
            _sessions =
                sessions;

            _state =
                state;

            _rules =
                rules;
        }

        public Result Execute(
            MovementCommand command,
            ServerTick currentTick)
        {
            if (!_sessions.TryGet(
                    command.Envelope.SessionId,
                    out PlayerSession session))
            {
                return Result.Failure(
                    "movement.session_missing");
            }

            if (!session.IsAuthenticated)
            {
                return Result.Failure(
                    "movement.not_authenticated");
            }

            if (!_state.Players.TryGet(
                    session.PlayerId,
                    out PlayerState player))
            {
                return Result.Failure(
                    "movement.player_missing");
            }

            if (!player.IsAlive)
            {
                return Result.Failure(
                    "movement.player_dead");
            }

            float x =
                command.Input.Horizontal /
                1000f;

            float y =
                command.Input.Vertical /
                1000f;

            float magnitude =
                x * x +
                y * y;

            if (magnitude > 1f)
            {
                float scale =
                    1f /
                    (float)
                    System.Math.Sqrt(
                        magnitude);

                x *= scale;
                y *= scale;
            }

            float speed =
                command.Input.Sprint
                    ? _rules.SprintSpeed
                    : _rules.WalkSpeed;

            Position2 next =
                player.Position.Add(
                    x *
                    speed *
                    _rules.FixedDeltaTime,
                    y *
                    speed *
                    _rules.FixedDeltaTime);

            player.SetPosition(
                next);

            _state.MarkChanged();

            return Result.Success();
        }
    }
}
