namespace CostOfStaying.Core
{
    public sealed class CoreComposition
    {
        public MatchRules Rules {
            get;
        }

        public CoreTickState Ticks {
            get;
        }

        public AuthoritativeState State {
            get;
        }

        public SessionRepository Sessions {
            get;
        }

        public CommandEnvelopeFactory Envelopes {
            get;
        }

        public MovementCommandIngress
            MovementIngress {
            get;
        }

        public BetrayalCommandIngress
            BetrayalIngress {
            get;
        }

        public CorePipeline Pipeline {
            get;
        }

        public CoreSnapshotFactory Snapshots {
            get;
        }

        public SessionLifecycleService
            SessionLifecycle {
            get;
        }

        private CoreComposition(
            MatchRules rules,
            CoreTickState ticks,
            AuthoritativeState state,
            SessionRepository sessions,
            CommandEnvelopeFactory envelopes,
            MovementCommandIngress movementIngress,
            BetrayalCommandIngress betrayalIngress,
            CorePipeline pipeline,
            CoreSnapshotFactory snapshots,
            SessionLifecycleService
                sessionLifecycle)
        {
            Rules =
                rules;

            Ticks =
                ticks;

            State =
                state;

            Sessions =
                sessions;

            Envelopes =
                envelopes;

            MovementIngress =
                movementIngress;

            BetrayalIngress =
                betrayalIngress;

            Pipeline =
                pipeline;

            Snapshots =
                snapshots;

            SessionLifecycle =
                sessionLifecycle;
        }

        public static Result<CoreComposition>
            Create(
                MatchRules rules,
                MovementRules movementRules,
                double fixedDeltaTime,
                CommandAdmissionRules
                    admissionRules)
        {
            if (fixedDeltaTime <= 0d)
            {
                return Result<CoreComposition>.Failure(
                    "core.fixed_delta_invalid");
            }

            var ticks =
                new CoreTickState();

            var state =
                new AuthoritativeState(
                    rules.MaximumPlayers);

            var sessions =
                new SessionRepository();

            var presence =
                new PresenceState();

            var participation =
                new ParticipationState();

            var lifecycle =
                new SessionLifecycleService(
                    sessions,
                    presence,
                    participation,
                    state,
                    rules.StartingVitality);

            var envelopes =
                new CommandEnvelopeFactory(
                    admissionRules,
                    ticks);

            var movementIngress =
                new MovementCommandIngress(
                    rules.QueueOptions);

            var betrayalIngress =
                new BetrayalCommandIngress(
                    rules.QueueOptions);

            var movement =
                new MovementService(
                    sessions,
                    state,
                    movementRules);

            var betrayal =
                new BetrayalService(
                    sessions,
                    presence,
                    state,
                    rules.Betrayal);

            var sequences =
                new CommandSequenceTracker(
                    admissionRules.MaximumSequenceJump);

            var pipeline =
                new CorePipeline(
                    ticks,
                    movementIngress,
                    betrayalIngress,
                    movement,
                    betrayal,
                    state,
                    sequences);

            var snapshots =
                new CoreSnapshotFactory(
                    state);

            return Result<CoreComposition>.Success(
                new CoreComposition(
                    rules,
                    ticks,
                    state,
                    sessions,
                    envelopes,
                    movementIngress,
                    betrayalIngress,
                    pipeline,
                    snapshots,
                    lifecycle));
        }
    }
}
