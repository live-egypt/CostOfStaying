namespace CostOfStaying.Core
{
    public readonly struct MatchRules
    {
        public int MaximumPlayers {
            get;
        }

        public int StartingVitality {
            get;
        }

        public CommandQueueOptions QueueOptions {
            get;
        }

        public BetrayalRules Betrayal {
            get;
        }

        public MatchRules(
            int maximumPlayers,
            int startingVitality,
            CommandQueueOptions queueOptions,
            BetrayalRules betrayal)
        {
            MaximumPlayers =
                maximumPlayers <= 0
                    ? 1
                    : maximumPlayers;

            StartingVitality =
                startingVitality < 0
                    ? 0
                    : startingVitality;

            QueueOptions =
                queueOptions;

            Betrayal =
                betrayal;
        }
    }
}
