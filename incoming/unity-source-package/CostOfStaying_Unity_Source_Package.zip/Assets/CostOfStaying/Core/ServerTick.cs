namespace CostOfStaying.Core
{
    public readonly struct ServerTick
    {
        public long Value {
            get;
        }

        public ServerTick(
            long value)
        {
            Value =
                value < 0
                    ? 0
                    : value;
        }

        public static ServerTick Zero =>
            new ServerTick(0);

        public ServerTick Next()
        {
            return new ServerTick(
                Value + 1);
        }

        public override string ToString()
        {
            return Value.ToString();
        }
    }
}
