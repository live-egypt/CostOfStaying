namespace CostOfStaying.Core
{
    public readonly struct MatchSnapshot
    {
        public MatchLifecycleState Lifecycle {
            get;
        }

        public int ConnectedPlayers {
            get;
        }

        public int MaximumPlayers {
            get;
        }

        public StateRevision Revision {
            get;
        }

        public MatchSnapshot(
            MatchLifecycleState lifecycle,
            int connectedPlayers,
            int maximumPlayers,
            StateRevision revision)
        {
            Lifecycle =
                lifecycle;

            ConnectedPlayers =
                connectedPlayers;

            MaximumPlayers =
                maximumPlayers;

            Revision =
                revision;
        }
    }
}
