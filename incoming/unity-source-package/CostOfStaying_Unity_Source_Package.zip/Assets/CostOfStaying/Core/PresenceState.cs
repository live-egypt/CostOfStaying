using System.Collections.Generic;

namespace CostOfStaying.Core
{
    public sealed class PresenceState
    {
        private readonly Dictionary<
            PlayerId,
            ServerTick>
            _onlineSince;

        public PresenceState()
        {
            _onlineSince =
                new Dictionary<
                    PlayerId,
                    ServerTick>();
        }

        public bool IsOnline(
            PlayerId playerId)
        {
            return _onlineSince.ContainsKey(
                playerId);
        }

        public void SetOnline(
            PlayerId playerId,
            ServerTick tick)
        {
            _onlineSince[playerId] =
                tick;
        }

        public void SetOffline(
            PlayerId playerId)
        {
            _onlineSince.Remove(
                playerId);
        }
    }
}
