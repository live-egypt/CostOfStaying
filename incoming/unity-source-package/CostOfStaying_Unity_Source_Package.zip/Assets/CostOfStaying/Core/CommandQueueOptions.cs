namespace CostOfStaying.Core
{
    public readonly struct CommandQueueOptions
    {
        public int MaximumCommandsPerTick {
            get;
        }

        public int MaximumLateTicks {
            get;
        }

        public CommandQueueOptions(
            int maximumCommandsPerTick,
            int maximumLateTicks)
        {
            MaximumCommandsPerTick =
                maximumCommandsPerTick <= 0
                    ? 1
                    : maximumCommandsPerTick;

            MaximumLateTicks =
                maximumLateTicks < 0
                    ? 0
                    : maximumLateTicks;
        }
    }
}
