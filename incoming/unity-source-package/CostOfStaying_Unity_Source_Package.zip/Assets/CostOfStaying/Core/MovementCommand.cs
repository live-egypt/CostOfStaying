namespace CostOfStaying.Core
{
    public readonly struct MovementCommand
    {
        public CommandEnvelope Envelope {
            get;
        }

        public MovementInput Input {
            get;
        }

        public MovementCommand(
            CommandEnvelope envelope,
            MovementInput input)
        {
            Envelope =
                envelope;

            Input =
                input;
        }
    }
}
