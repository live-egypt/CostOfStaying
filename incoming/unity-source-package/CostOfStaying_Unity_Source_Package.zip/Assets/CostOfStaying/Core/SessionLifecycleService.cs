namespace CostOfStaying.Core
{
    public sealed class SessionLifecycleService
    {
        private readonly SessionRepository
            _sessions;

        private readonly PresenceState
            _presence;

        private readonly ParticipationState
            _participation;

        private readonly AuthoritativeState
            _authoritative;

        private readonly int
            _startingVitality;

        public SessionLifecycleService(
            SessionRepository sessions,
            PresenceState presence,
            ParticipationState participation,
            AuthoritativeState authoritative,
            int startingVitality)
        {
            _sessions =
                sessions;

            _presence =
                presence;

            _participation =
                participation;

            _authoritative =
                authoritative;

            _startingVitality =
                startingVitality < 0
                    ? 0
                    : startingVitality;
        }

        public Result<PlayerSession> Connect(
            PlayerId playerId,
            int clientId,
            ServerTick tick)
        {
            if (_sessions.TryGetByPlayer(
                    playerId,
                    out PlayerSession existing))
            {
                return Result<PlayerSession>.Failure(
                    "session.player_already_active");
            }

            Result capacity =
                _authoritative.Match.AddPlayer();

            if (!capacity.IsSuccess)
            {
                return Result<PlayerSession>.Failure(
                    capacity.ErrorCode);
            }

            var session =
                new PlayerSession(
                    SessionId.New(),
                    playerId,
                    clientId);

            Result added =
                _sessions.Add(
                    session);

            if (!added.IsSuccess)
            {
                _authoritative.Match.RemovePlayer();

                return Result<PlayerSession>.Failure(
                    added.ErrorCode);
            }

            var player =
                new PlayerState(
                    playerId,
                    _startingVitality,
                    new Position2(0f, 0f));

            Result playerAdded =
                _authoritative.Players.Add(
                    player);

            if (!playerAdded.IsSuccess)
            {
                _sessions.Remove(
                    session.SessionId);

                _authoritative.Match.RemovePlayer();

                return Result<PlayerSession>.Failure(
                    playerAdded.ErrorCode);
            }

            _presence.SetOnline(
                playerId,
                tick);

            _authoritative.MarkChanged();

            return Result<PlayerSession>.Success(
                session);
        }

        public Result Authenticate(
            SessionId sessionId)
        {
            if (!_sessions.TryGet(
                    sessionId,
                    out PlayerSession session))
            {
                return Result.Failure(
                    "session.not_found");
            }

            return session.Authenticate();
        }

        public Result Disconnect(
            SessionId sessionId)
        {
            if (!_sessions.TryGet(
                    sessionId,
                    out PlayerSession session))
            {
                return Result.Failure(
                    "session.not_found");
            }

            session.Disconnect();

            _presence.SetOffline(
                session.PlayerId);

            _participation.Remove(
                session.PlayerId);

            _authoritative.Players.Remove(
                session.PlayerId);

            _authoritative.Match.RemovePlayer();

            Result removed =
                _sessions.Remove(
                    sessionId);

            if (removed.IsSuccess)
            {
                _authoritative.MarkChanged();
            }

            return removed;
        }
    }
}
