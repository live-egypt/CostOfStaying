using System.Collections.Generic;

namespace CostOfStaying.Core
{
    public sealed class MovementCommandIngress
    {
        private readonly Queue<
            MovementCommand>
            _commands;

        private readonly CommandQueueOptions
            _options;

        public MovementCommandIngress(
            CommandQueueOptions options)
        {
            _options =
                options;

            _commands =
                new Queue<
                    MovementCommand>();
        }

        public Result Enqueue(
            MovementCommand command,
            ServerTick currentTick)
        {
            if (_commands.Count >=
                _options.MaximumCommandsPerTick *
                4)
            {
                return Result.Failure(
                    "movement.queue_full");
            }

            if (IsTooLate(
                    command.Envelope.RequestedTick,
                    currentTick))
            {
                return Result.Failure(
                    "movement.command_too_old");
            }

            _commands.Enqueue(
                command);

            return Result.Success();
        }

        public bool TryDequeue(
            out MovementCommand command)
        {
            if (_commands.Count == 0)
            {
                command =
                    default;

                return false;
            }

            command =
                _commands.Dequeue();

            return true;
        }

        public int Count =>
            _commands.Count;

        private bool IsTooLate(
            ServerTick requested,
            ServerTick current)
        {
            long delta =
                current.Value -
                requested.Value;

            return delta >
                   _options.MaximumLateTicks;
        }
    }
}
