namespace CostOfStaying.Core
{
    public sealed class BetrayalService
    {
        private readonly SessionRepository
            _sessions;

        private readonly PresenceState
            _presence;

        private readonly AuthoritativeState
            _state;

        private readonly BetrayalRules
            _rules;

        public BetrayalService(
            SessionRepository sessions,
            PresenceState presence,
            AuthoritativeState state,
            BetrayalRules rules)
        {
            _sessions =
                sessions;

            _presence =
                presence;

            _state =
                state;

            _rules =
                rules;
        }

        public Result Execute(
            BetrayalCommand command,
            ServerTick currentTick)
        {
            if (!_sessions.TryGet(
                    command.Envelope.SessionId,
                    out PlayerSession attacker))
            {
                return Result.Failure(
                    "betrayal.attacker_session_missing");
            }

            if (!attacker.IsAuthenticated)
            {
                return Result.Failure(
                    "betrayal.attacker_not_authenticated");
            }

            if (!_state.Players.TryGet(
                    attacker.PlayerId,
                    out PlayerState attackerState))
            {
                return Result.Failure(
                    "betrayal.attacker_missing");
            }

            if (!_state.Players.TryGet(
                    command.VictimId,
                    out PlayerState victimState))
            {
                return Result.Failure(
                    "betrayal.victim_missing");
            }

            if (_rules.RequiresAliveAttacker &&
                !attackerState.IsAlive)
            {
                return Result.Failure(
                    "betrayal.attacker_dead");
            }

            if (!_presence.IsOnline(
                    command.VictimId))
            {
                return Result.Failure(
                    "betrayal.victim_offline");
            }

            if (!victimState.IsAlive)
            {
                return Result.Failure(
                    "betrayal.victim_dead");
            }

            if (attacker.PlayerId ==
                command.VictimId)
            {
                return Result.Failure(
                    "betrayal.self_target");
            }

            Result damage =
                victimState.ApplyDamage(
                    _rules.VitalityDamage);

            if (!damage.IsSuccess)
            {
                return damage;
            }

            _state.MarkChanged();

            return Result.Success();
        }
    }
}
