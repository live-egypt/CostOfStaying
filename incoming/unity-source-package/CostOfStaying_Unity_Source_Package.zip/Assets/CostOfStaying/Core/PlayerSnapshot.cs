namespace CostOfStaying.Core
{
    public readonly struct PlayerSnapshot
    {
        public PlayerId PlayerId {
            get;
        }

        public int Vitality {
            get;
        }

        public bool IsAlive {
            get;
        }

        public Position2 Position {
            get;
        }

        public PlayerSnapshot(
            PlayerId playerId,
            int vitality,
            bool isAlive,
            Position2 position)
        {
            PlayerId =
                playerId;

            Vitality =
                vitality;

            IsAlive =
                isAlive;

            Position =
                position;
        }
    }
}
