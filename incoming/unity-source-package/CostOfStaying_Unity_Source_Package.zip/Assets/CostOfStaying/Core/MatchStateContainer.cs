namespace CostOfStaying.Core
{
    public sealed class MatchStateContainer
    {
        public PresenceState Presence {
            get;
        }

        public ParticipationState Participation {
            get;
        }

        public StateRevision Revision {
            get;
            private set;
        }

        public MatchStateContainer()
        {
            Presence =
                new PresenceState();

            Participation =
                new ParticipationState();

            Revision =
                new StateRevision(0);
        }

        public void MarkChanged()
        {
            Revision =
                Revision.Next();
        }
    }
}
