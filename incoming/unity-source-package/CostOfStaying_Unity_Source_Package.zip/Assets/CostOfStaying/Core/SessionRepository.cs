using System.Collections.Generic;

namespace CostOfStaying.Core
{
    public sealed class SessionRepository
    {
        private readonly Dictionary<
            SessionId,
            PlayerSession>
            _sessions;

        private readonly Dictionary<
            PlayerId,
            SessionId>
            _playerSessions;

        public SessionRepository()
        {
            _sessions =
                new Dictionary<
                    SessionId,
                    PlayerSession>();

            _playerSessions =
                new Dictionary<
                    PlayerId,
                    SessionId>();
        }

        public Result Add(
            PlayerSession session)
        {
            if (session == null)
            {
                return Result.Failure(
                    "session.null");
            }

            if (_sessions.ContainsKey(
                    session.SessionId))
            {
                return Result.Failure(
                    "session.duplicate_id");
            }

            if (_playerSessions.ContainsKey(
                    session.PlayerId))
            {
                return Result.Failure(
                    "session.player_already_active");
            }

            _sessions.Add(
                session.SessionId,
                session);

            _playerSessions.Add(
                session.PlayerId,
                session.SessionId);

            return Result.Success();
        }

        public bool TryGet(
            SessionId id,
            out PlayerSession session)
        {
            return _sessions.TryGetValue(
                id,
                out session);
        }

        public bool TryGetByPlayer(
            PlayerId id,
            out PlayerSession session)
        {
            session =
                null;

            if (!_playerSessions.TryGetValue(
                    id,
                    out SessionId sessionId))
            {
                return false;
            }

            return _sessions.TryGetValue(
                sessionId,
                out session);
        }

        public Result Remove(
            SessionId id)
        {
            if (!_sessions.TryGetValue(
                    id,
                    out PlayerSession session))
            {
                return Result.Failure(
                    "session.not_found");
            }

            _sessions.Remove(
                id);

            _playerSessions.Remove(
                session.PlayerId);

            return Result.Success();
        }

        public void Clear()
        {
            _sessions.Clear();
            _playerSessions.Clear();
        }

        public int Count =>
            _sessions.Count;
    }
}
