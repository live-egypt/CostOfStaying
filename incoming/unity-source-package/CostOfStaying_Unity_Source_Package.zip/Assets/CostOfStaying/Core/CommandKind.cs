namespace CostOfStaying.Core
{
    public enum CommandKind : byte
    {
        Movement = 0,
        Betrayal = 1
    }
}
