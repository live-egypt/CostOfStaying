using System.Collections.Generic;

namespace CostOfStaying.Core
{
    public sealed class CoreSnapshotFactory
    {
        private readonly AuthoritativeState
            _state;

        public CoreSnapshotFactory(
            AuthoritativeState state)
        {
            _state =
                state;
        }

        public CoreSnapshot Create(
            ServerTick tick)
        {
            var players =
                new List<PlayerSnapshot>(
                    _state.Players.Count);

            foreach (
                PlayerId playerId in
                GetPlayerIds())
            {
                if (!_state.Players.TryGet(
                        playerId,
                        out PlayerState player))
                {
                    continue;
                }

                players.Add(
                    new PlayerSnapshot(
                        player.PlayerId,
                        player.Vitality,
                        player.IsAlive,
                        player.Position));
            }

            var match =
                new MatchSnapshot(
                    _state.Match.Lifecycle,
                    _state.Match.ConnectedPlayers,
                    _state.Match.MaximumPlayers,
                    _state.Revision);

            return new CoreSnapshot(
                tick,
                _state.Revision,
                match,
                players);
        }

        private IEnumerable<PlayerId>
            GetPlayerIds()
        {
            return _state.Players.Ids;
        }
    }
}
