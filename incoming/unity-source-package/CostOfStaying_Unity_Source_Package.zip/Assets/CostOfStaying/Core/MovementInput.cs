namespace CostOfStaying.Core
{
    public readonly struct MovementInput
    {
        public short Horizontal {
            get;
        }

        public short Vertical {
            get;
        }

        public bool Sprint {
            get;
        }

        public MovementInput(
            short horizontal,
            short vertical,
            bool sprint)
        {
            Horizontal =
                Clamp(horizontal);

            Vertical =
                Clamp(vertical);

            Sprint =
                sprint;
        }

        private static short Clamp(
            short value)
        {
            if (value < -1000)
            {
                return -1000;
            }

            if (value > 1000)
            {
                return 1000;
            }

            return value;
        }
    }
}
