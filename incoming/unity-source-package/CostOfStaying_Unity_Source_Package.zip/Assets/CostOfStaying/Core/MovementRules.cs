namespace CostOfStaying.Core
{
    public readonly struct MovementRules
    {
        public float WalkSpeed {
            get;
        }

        public float SprintSpeed {
            get;
        }

        public float FixedDeltaTime {
            get;
        }

        public MovementRules(
            float walkSpeed,
            float sprintSpeed,
            float fixedDeltaTime)
        {
            WalkSpeed =
                walkSpeed < 0f
                    ? 0f
                    : walkSpeed;

            SprintSpeed =
                sprintSpeed < 0f
                    ? 0f
                    : sprintSpeed;

            FixedDeltaTime =
                fixedDeltaTime <= 0f
                    ? 0.05f
                    : fixedDeltaTime;
        }
    }
}
