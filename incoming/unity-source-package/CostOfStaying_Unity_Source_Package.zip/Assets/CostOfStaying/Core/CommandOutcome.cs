namespace CostOfStaying.Core
{
    public readonly struct CommandOutcome
    {
        public SessionId SessionId {
            get;
        }

        public CommandKind Kind {
            get;
        }

        public long ClientSequence {
            get;
        }

        public bool Accepted {
            get;
        }

        public string Code {
            get;
        }

        public ServerTick Tick {
            get;
        }

        private CommandOutcome(
            SessionId sessionId,
            CommandKind kind,
            long clientSequence,
            bool accepted,
            string code,
            ServerTick tick)
        {
            SessionId =
                sessionId;

            Kind =
                kind;

            ClientSequence =
                clientSequence;

            Accepted =
                accepted;

            Code =
                code ?? string.Empty;

            Tick =
                tick;
        }

        public static CommandOutcome Success(
            SessionId sessionId,
            CommandKind kind,
            long sequence,
            ServerTick tick)
        {
            return new CommandOutcome(
                sessionId,
                kind,
                sequence,
                true,
                string.Empty,
                tick);
        }

        public static CommandOutcome Failure(
            SessionId sessionId,
            CommandKind kind,
            long sequence,
            string code,
            ServerTick tick)
        {
            return new CommandOutcome(
                sessionId,
                kind,
                sequence,
                false,
                code,
                tick);
        }
    }
}
